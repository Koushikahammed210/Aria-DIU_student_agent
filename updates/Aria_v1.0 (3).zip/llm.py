# llm.py - Smart router: Ollama for reasoning, Gemini for final answers only
# Supports Ollama vision models (llava) for image analysis

import ollama
from google import genai
from google.genai import types
from config import MODEL_OLLAMA, MODEL_GEMINI, GEMINI_API_KEY, DEFAULT_MODE

client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

# Session-level quota tracker
_gemini_quota_exceeded = False

# ── Vision model detection ──────────────────────────────────────────────────────
_VISION_MODELS = [
    "llava", "llava:latest", "llava:7b", "llava:13b", "llava:34b",
    "llava-llama3", "llava-llama3:latest",
    "bakllava", "bakllava:latest",
    "llava-phi3", "llava-phi3:latest",
    "minicpm-v", "minicpm-v:latest",
    "moondream", "moondream:latest", "moondream2",
    "llava-v1.6", "llava-v1.6-vicuna", "llava-v1.6-mistral",
    "xgen-mm", "fuyu", "cogvlm",
]


def get_available_models():
    """Get list of locally available Ollama models."""
    try:
        models_info = ollama.list()
        # Handle both old dict format and new Ollama Python client API (0.4.x+)
        if hasattr(models_info, 'models'):
            models_list = models_info.models
        elif isinstance(models_info, dict):
            models_list = models_info.get('models', [])
        else:
            models_list = []

        names = []
        for m in models_list:
            if hasattr(m, 'model'):
                names.append(m.model)
            elif isinstance(m, dict):
                names.append(m.get('model', m.get('name', '')))
        return [n for n in names if n]
    except Exception as e:
        print(f"  [Warning: Could not list Ollama models: {e}]")
        return []


def _find_vision_model():
    """Find a suitable vision model from locally installed Ollama models."""
    available = get_available_models()
    if not available:
        return None

    # Tier 1: Exact match from _VISION_MODELS list
    for vm in _VISION_MODELS:
        if vm in available:
            return vm

    # Tier 2: Base name match (e.g., available "llava:7b" matches base "llava")
    available_bases = {}
    for m in available:
        base = m.split(':')[0]
        available_bases[base] = m  # store the full name (with tag)

    for vm in _VISION_MODELS:
        base = vm.split(':')[0]
        if base in available_bases:
            return available_bases[base]

    # Tier 3: Fuzzy keyword match
    vision_keywords = ['llava', 'vision', 'bakllava', 'moondream', 'minicpm-v', 'xgen-mm']
    for m in available:
        lower = m.lower()
        for kw in vision_keywords:
            if kw in lower:
                return m

    return None


def has_vision_model():
    """Check if a local Ollama vision model is available."""
    return _find_vision_model() is not None


# ── Simple / Complex patterns ──────────────────────────────────────────────────
SIMPLE_PATTERNS = [
    "what time", "what's the time", "current time", "date today",
    "what day", "hello", "hi ", "hey ", "who are you", "your name",
    "what model", "what are you", "status", "help", "who built",
    "who made", "who created", "who is your"
]

COMPLEX_KEYWORDS = [
    "analyze", "write", "explain", "compare", "summarize",
    "code", "debug", "plan", "research", "essay", "report",
    "translate", "review", "generate", "describe", "elaborate"
]


def is_gemini_available() -> bool:
    global _gemini_quota_exceeded
    if _gemini_quota_exceeded:
        return False
    if not GEMINI_API_KEY or not client:
        return False
    import socket
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=2)
        return True
    except OSError:
        return False


def mark_quota_exceeded():
    global _gemini_quota_exceeded
    _gemini_quota_exceeded = True
    print("  [Gemini quota exceeded — switching to Ollama for this session]")


def chat_ollama(messages: list) -> str:
    """Always use Ollama — for tool reasoning steps."""
    try:
        clean = [{"role": m["role"], "content": m["content"]} for m in messages]
        response = ollama.chat(model=MODEL_OLLAMA, messages=clean)
        # Handle both dict-like and attribute-based response (ollama 0.4+ returns pydantic)
        if hasattr(response, 'message') and hasattr(response.message, 'content'):
            return (response.message.content or '').strip()
        elif isinstance(response, dict):
            return response.get('message', {}).get('content', '').strip()
        return str(response).strip()
    except Exception as e:
        return f"Ollama error: {e}"


def chat_gemini(messages: list) -> str:
    """Use Gemini — only for final answers on complex tasks."""
    global _gemini_quota_exceeded
    if not is_gemini_available():
        return chat_ollama(messages)
    try:
        system_text = ""
        history = []
        for m in messages:
            if m["role"] == "system":
                system_text = m["content"]
            elif m["role"] == "user":
                history.append(types.Content(
                    role="user",
                    parts=[types.Part(text=m["content"])]
                ))
            elif m["role"] == "assistant":
                history.append(types.Content(
                    role="model",
                    parts=[types.Part(text=m["content"])]
                ))
        if not history:
            return chat_ollama(messages)
        last_content = history[-1].parts[0].text
        prior_history = history[:-1]
        config = types.GenerateContentConfig(
            system_instruction=system_text if system_text else None,
        )
        session = client.chats.create(
            model=MODEL_GEMINI,
            history=prior_history,
            config=config,
        )
        response = session.send_message(last_content)
        return response.text.strip()
    except Exception as e:
        err = str(e)
        if "429" in err or "quota" in err.lower() or "exhausted" in err.lower():
            mark_quota_exceeded()
            return chat_ollama(messages)
        return f"Gemini error: {e}"


def chat(messages: list, mode: str = DEFAULT_MODE) -> str:
    if mode == "ollama":
        return chat_ollama(messages)
    if mode == "gemini":
        return chat_gemini(messages)
    return chat_ollama(messages)


def should_use_gemini_for_final(user_input: str, mode: str) -> bool:
    if mode == "ollama":
        return False
    if not is_gemini_available():
        return False
    last = user_input.lower()
    if any(p in last for p in SIMPLE_PATTERNS):
        return False
    if mode == "gemini":
        return True
    return any(k in last for k in COMPLEX_KEYWORDS)


# ── Vision (Image Analysis) ────────────────────────────────────────────────────
import re as _re

# Phrases that indicate the vision model didn't actually see the image
_BLIND_PHRASES = [
    "i don't actually see", "i cannot see", "i can't see",
    "i am unable to see", "no image is visible", "there is no image",
    "i'm not able to see", "i am not able to see", "i don't see an image",
    "i don't see any image", "no visual content", "no image present",
    "i'm a text-based", "i'm a text only", "text-only model",
    "cannot process images", "cannot view images", "cannot see images",
]


def _clean_vision_output(text: str) -> str:
    """Remove garbage tokens like <unk>, repeated patterns, etc. from LLaVA output."""
    # Remove <unk> tokens
    text = _re.sub(r'<unk>', '', text)
    # Remove other special tokens
    text = _re.sub(r'<[a-z]+>', '', text)
    # Remove excessive whitespace
    text = _re.sub(r'\s+', ' ', text).strip()
    # Remove lines that are just special chars
    lines = text.split('\n')
    lines = [l for l in lines if l.strip() and not _re.match(r'^[\s\W]+$', l)]
    return '\n'.join(lines).strip()


def _is_blind_response(text: str) -> bool:
    """Check if the model claims it can't see the image (hallucination)."""
    lower = text.lower()
    return any(phrase in lower for phrase in _BLIND_PHRASES)


def _prepare_images(images: list) -> list:
    """Extract clean base64 strings from image dicts, stripping data URI prefixes."""
    b64_list = []
    for img in images:
        b64 = img.get('base64', '')
        # Strip data URI prefix if present (e.g. "data:image/jpeg;base64,")
        if b64.startswith('data:'):
            b64 = b64.split(',', 1)[-1]
        b64_list.append(b64)
    return b64_list


def _try_ollama_vision(text: str, images: list) -> str:
    """
    Send text + images to an Ollama vision model (e.g., llava).
    Uses ollama.chat() with a system prompt to ensure the model
    knows it has received an image and should describe it.
    images: list of {base64: str, mime: str}
    Returns the model's response text, or raises Exception on failure.
    """
    vision_model = _find_vision_model()
    if not vision_model:
        raise RuntimeError(
            "No Ollama vision model found. Install one with: ollama pull llava"
        )

    b64_images = _prepare_images(images)
    if not b64_images:
        raise RuntimeError("No valid image data provided")

    print(f"  [Ollama Vision: using {vision_model} with {len(b64_images)} image(s), img size ~{len(b64_images[0])//1024}KB]")

    # System prompt that explicitly tells the model it has received an image
    # This prevents LLaVA from hallucinating "I can't see the image"
    system_prompt = (
        "You are a helpful vision assistant. The user has shared an image with you. "
        "You CAN see and analyze this image. Describe what you see in detail. "
        "Do NOT say you cannot see the image — the image is attached to your input. "
        "Provide a thorough, accurate description of the visual content."
    )

    # Strategy 1: Try ollama.chat() with system + user messages
    try:
        response = ollama.chat(
            model=vision_model,
            messages=[
                {'role': 'system', 'content': system_prompt},
                {
                    'role': 'user',
                    'content': text if text else "Describe this image in detail.",
                    'images': b64_images
                }
            ]
        )
        # Handle both dict-like and attribute-based response (ollama 0.4+ returns pydantic)
        content = ''
        if hasattr(response, 'message') and hasattr(response.message, 'content'):
            content = response.message.content or ''
        elif isinstance(response, dict):
            content = response.get('message', {}).get('content', '')
        content = content.strip()
        content = _clean_vision_output(content)

        if content and not _is_blind_response(content):
            print(f"  [Ollama Vision: got response via chat() — {len(content)} chars]")
            return content
        else:
            print(f"  [Ollama Vision: chat() returned blind/empty response, trying generate()]")
    except Exception as e:
        print(f"  [Ollama Vision: chat() failed ({e}), trying generate()]")

    # Strategy 2: Try ollama.generate() as fallback
    # Some LLaVA versions work better with generate() than chat()
    # generate() accepts both base64 strings and bytes for images
    try:
        response = ollama.generate(
            model=vision_model,
            prompt=text if text else "Describe this image in detail.",
            images=b64_images,  # pass base64 strings; ollama wraps them in Image()
            system=system_prompt,
        )
        # Handle both dict-like and attribute-based response access
        content = ''
        if hasattr(response, 'response'):
            content = response.response or ''
        elif isinstance(response, dict):
            content = response.get('response', '')
        content = content.strip()
        content = _clean_vision_output(content)

        if content and not _is_blind_response(content):
            print(f"  [Ollama Vision: got response via generate() — {len(content)} chars]")
            return content
        else:
            print(f"  [Ollama Vision: generate() also returned blind/empty response]")
    except Exception as e:
        print(f"  [Ollama Vision: generate() also failed ({e})")

    # If we got here, both strategies returned blind responses
    raise RuntimeError(
        f"Ollama vision model ({vision_model}) did not properly analyze the image. "
        f"The model may need to be restarted or the image format may be unsupported."
    )


def chat_with_images(text: str, images: list) -> str:
    """
    Send text + images to vision models.
    Priority: Ollama Vision (llava) → Gemini Vision → text-only fallback
    images: list of {base64: str, mime: str}
    """
    # ── Attempt 1: Ollama Vision (llava, etc.) — fastest and most reliable ──
    try:
        return _try_ollama_vision(text, images)
    except Exception as e:
        print(f"  [Ollama Vision failed: {e}]")

    # ── Attempt 2: Gemini Vision ────────────────────────────────────────────
    if is_gemini_available():
        try:
            import base64 as _b64
            parts = []
            for img in images:
                raw_b64 = img.get('base64', '')
                if raw_b64.startswith('data:'):
                    raw_b64 = raw_b64.split(',', 1)[-1]
                parts.append(types.Part(
                    inline_data=types.Blob(
                        mime_type=img.get('mime', 'image/jpeg'),
                        data=_b64.b64decode(raw_b64)
                    )
                ))
            parts.append(types.Part(text=text))
            response = client.models.generate_content(
                model=MODEL_GEMINI,
                contents=[types.Content(role="user", parts=parts)]
            )
            return response.text.strip()
        except Exception as e:
            err = str(e)
            if "429" in err or "quota" in err.lower():
                mark_quota_exceeded()
                print("  [Gemini Vision quota exceeded]")
            else:
                print(f"  [Gemini Vision error: {err[:120]}]")

    # ── Fallback: text-only response ────────────────────────────────────────
    vision_model_name = _find_vision_model()
    if vision_model_name:
        return (
            f"I can see you've shared an image! Unfortunately, both Ollama vision "
            f"({vision_model_name}) and Gemini Vision failed to process it.\n\n"
            f"Please try again or describe the image in text."
        )
    else:
        return (
            f"I can see you've shared an image! Unfortunately, I couldn't analyze it because:\n\n"
            f"1. No Ollama vision model is installed\n"
            f"2. Gemini Vision is currently unavailable\n\n"
            f"To enable image analysis, install a vision model:\n"
            f"  ollama pull llava\n\n"
            f"Then restart Aria."
        )
