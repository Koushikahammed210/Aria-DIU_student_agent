# tools.py

import os
import re
import json
import requests
from datetime import datetime
from ddgs import DDGS
from config import SEARCH_MAX_RESULTS


# ── Web Search ────────────────────────────────────────────────────────────────
def web_search(query: str) -> str:
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=SEARCH_MAX_RESULTS))
        if not results:
            return "No results found."
        output = []
        for i, r in enumerate(results, 1):
            output.append(f"{i}. {r['title']}\n   {r['body']}\n   Source: {r['href']}")
        return "\n\n".join(output)
    except Exception as e:
        return f"Search error: {e}"


# ── Wikipedia ─────────────────────────────────────────────────────────────────
def wikipedia_search(query: str) -> str:
    try:
        resp = requests.get(
            "https://en.wikipedia.org/api/rest_v1/page/summary/" + query.replace(" ", "_"),
            timeout=8
        )
        if resp.status_code == 200:
            data = resp.json()
            return f"{data['title']}\n\n{data['extract']}"
        return "No Wikipedia article found."
    except Exception as e:
        return f"Wikipedia error: {e}"


# ── Weather ───────────────────────────────────────────────────────────────────
def get_weather(location: str) -> str:
    try:
        url = f"https://wttr.in/{requests.utils.quote(location)}?format=3"
        resp = requests.get(url, timeout=8, headers={"User-Agent": "curl/7.0"})
        if resp.status_code == 200:
            return resp.text.strip()
        return f"Could not fetch weather for '{location}'."
    except Exception as e:
        return f"Weather error: {e}"


# ── Summarize Webpage ─────────────────────────────────────────────────────────
def summarize_webpage(url: str) -> str:
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        resp = requests.get(url, headers=headers, timeout=12)
        text = re.sub(r"<[^>]+>", " ", resp.text)
        text = re.sub(r"\s+", " ", text).strip()
        return f"[Content from {url}]\n\n{text[:4000]}"
    except Exception as e:
        return f"Fetch error: {e}"


# ── Fetch Webpage ─────────────────────────────────────────────────────────────
def fetch_webpage(url: str) -> str:
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        resp = requests.get(url, headers=headers, timeout=10)
        text = re.sub(r"<[^>]+>", " ", resp.text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:3000]
    except Exception as e:
        return f"Fetch error: {e}"


# ── File I/O ──────────────────────────────────────────────────────────────────
def read_file(filepath: str) -> str:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return f"File not found: {filepath}"
    except Exception as e:
        return f"Error reading file: {e}"


def write_file(filepath: str, content: str) -> str:
    try:
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Successfully wrote to {filepath}"
    except Exception as e:
        return f"Error writing file: {e}"


# ── Calculator ────────────────────────────────────────────────────────────────
def calculate(expression: str) -> str:
    try:
        expr = expression.strip()
        match = re.match(r"([\d.]+)\s*%\s*of\s*([\d.]+)", expr, re.IGNORECASE)
        if match:
            a, b = float(match.group(1)), float(match.group(2))
            return f"{a}% of {b} = {a / 100 * b}"
        expr = re.sub(r"([\d.]+)%", r"(\1/100)", expr)
        if not re.match(r"^[\d\s\+\-\*\/\.\(\)]+$", expr):
            return "Error: Only basic math expressions allowed."
        result = eval(expr)
        return f"{expression} = {result}"
    except Exception as e:
        return f"Calculation error: {e}"


# ── Date/Time ─────────────────────────────────────────────────────────────────
def get_datetime() -> str:
    return datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")


# ── File System ───────────────────────────────────────────────────────────────
def list_files(directory: str = ".") -> str:
    try:
        items = os.listdir(directory)
        return "\n".join(items) if items else "Directory is empty."
    except Exception as e:
        return f"Error: {e}"


# ── Run Python ────────────────────────────────────────────────────────────────
def run_python(code: str) -> str:
    import subprocess
    try:
        result = subprocess.run(
            ["python", "-c", code],
            capture_output=True, text=True, timeout=10
        )
        output = result.stdout.strip()
        error = result.stderr.strip()
        if error:
            return f"Error:\n{error}"
        return output if output else "Code ran with no output."
    except subprocess.TimeoutExpired:
        return "Error: Code timed out (10s limit)."
    except Exception as e:
        return f"Run error: {e}"


# ── DIU Cover Page Generator ──────────────────────────────────────────────────
def generate_covers(input_str: str) -> str:
    """
    Generate DIU assignment/lab cover pages (official format) and zip them.

    Expected JSON input:
    {
        "student_name": "...",
        "student_id": "...",
        "section": "...",
        "course_title": "...",
        "course_code": "...",
        "doc_type": "Lab Report" or "Assignment",
        "experiments": ["Exp 1 title", "Exp 2 title"]  -- OR --
                       [{"name": "Exp 1", "no": "1"}, ...],
        "department": "CSE" (optional, default CSE),
        "semester": "6TH" (optional),
        "teacher_name": "..." (optional),
        "teacher_designation": "LECTURER" (optional),
        "teacher_dept": "CSE" (optional),
        "date": "DD/MM/YYYY" (optional, defaults to today)
    }
    """
    try:
        # Handle both raw JSON string and escaped JSON string
        data = json.loads(input_str)
    except json.JSONDecodeError:
        # Try to extract JSON from the string if it's wrapped
        match = re.search(r'\{.*\}', input_str, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
            except json.JSONDecodeError as e:
                return f"Error: Could not parse input JSON — {e}"
        else:
            return "Error: Input must be a valid JSON object with student info and experiments list."

    required = ["student_name", "student_id", "section", "course_title", "course_code", "experiments"]
    missing = [k for k in required if k not in data]
    if missing:
        return f"Error: Missing required fields: {', '.join(missing)}"

    experiments = data.get("experiments", [])
    if not experiments:
        return "Error: 'experiments' list is empty. Provide at least one experiment name."

    try:
        from cover_generator import batch_create_covers
        student_info = {k: v for k, v in data.items() if k != "experiments"}
        zip_path = batch_create_covers(student_info, experiments)
        filename = os.path.basename(zip_path)
        count = len(experiments)
        return (
            f"SUCCESS: Cover pages generated! "
            f"{count} cover page(s) created. "
            f"Download ready: {filename}"
        )
    except Exception as e:
        return f"Cover generation error: {e}"


# ── Tool Registry ─────────────────────────────────────────────────────────────
TOOLS = {
    "web_search": {
        "fn": web_search,
        "description": "Search the web. Input: search query string.",
    },
    "wikipedia_search": {
        "fn": wikipedia_search,
        "description": "Look up a topic on Wikipedia. Input: topic name.",
    },
    "get_weather": {
        "fn": get_weather,
        "description": "Get current weather for a city. Input: city name (e.g. 'Dhaka' or 'London, UK').",
    },
    "summarize_webpage": {
        "fn": summarize_webpage,
        "description": "Fetch and return full text of a webpage for summarization. Input: full URL.",
    },
    "fetch_webpage": {
        "fn": fetch_webpage,
        "description": "Read raw content of a webpage. Input: full URL.",
    },
    "read_file": {
        "fn": read_file,
        "description": "Read a file from disk. Input: full file path.",
    },
    "write_file": {
        "fn": write_file,
        "description": "Write text to a file. Input: filepath|content (pipe-separated).",
    },
    "calculate": {
        "fn": calculate,
        "description": "Evaluate a math expression. Input: expression like '15% of 3500'.",
    },
    "get_datetime": {
        "fn": get_datetime,
        "description": "Get the current local date and time. Input: none",
    },
    "list_files": {
        "fn": list_files,
        "description": "List files in a directory. Input: directory path or '.'",
    },
    "run_python": {
        "fn": run_python,
        "description": "Run a Python code snippet and return output. Input: valid Python code.",
    },
    "generate_covers": {
        "fn": generate_covers,
        "description": (
            "Generate official DIU-format cover pages (Lab Report or Assignment) as a downloadable ZIP. "
            "Input: JSON string with: student_name, student_id, section, course_title, course_code, "
            'doc_type ("Lab Report" or "Assignment"), '
            "experiments (list of strings OR list of {name, no} objects). "
            "Optional: department, semester, teacher_name, teacher_designation, teacher_dept, date (DD/MM/YYYY). "
            'Example: {"student_name":"Koushik Ahammed","student_id":"241-15-259","section":"66_O",'
            '"semester":"6TH","department":"CSE","course_title":"Compiler Designer","course_code":"CSE313",'
            '"doc_type":"Lab Report","teacher_name":"Umme Habiba","teacher_designation":"Lecturer",'
            '"teacher_dept":"CSE","date":"15/04/2026",'
            '"experiments":[{"name":"Lexical Analysis","no":"1"},{"name":"Syntax Analysis","no":"2"}]}'
        ),
    },
}