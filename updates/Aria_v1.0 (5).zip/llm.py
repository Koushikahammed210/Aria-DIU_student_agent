# llm.py - Smart router: Ollama for reasoning, Gemini for final answers only
# Supports Ollama vision models (llava) for image analysis
# Gemini auto-recovery + rate limiter + context trimming + caching

import time
import ollama
from google import genai
from google.genai import types
from config import MODEL_OLLAMA, MODEL_GEMINI, GEMINI_API_KEY, DEFAULT_MODE

client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

# ── Gemini Rate Limiter & Auto-Recovery ─────────────────────────────────────
# Replaces the old permanent kill switch with smart cooldown + auto-recovery

class _GeminiManager:
    """
    Tracks Gemini API usage and auto-recovers from rate limits.
    - Monitors requests per minute (RPM) and per day (RPD)
    - Auto-cooldown when rate limit is hit (not permanent kill)
    - Exponential backoff: 60s → 120s → 240s on repeated failures
    - Auto-recovers when cooldown expires
    """
    # Gemini free tier limits
    RPM_LIMIT = 15          # Requests per minute
    RPD_LIMIT = 1500        # Requests per day
    RPM_SAFE = 12           # Stay under this to avoid hitting limit
    MAX_CONTEXT_MESSAGES = 8  # Max history messages sent to Gemini
    MAX_OUTPUT_TOKENS = 2048  # Token budget per response

    def __init__(self):
        self._cooldown_until = 0      # Timestamp when cooldown expires
        self._backoff_level = 0       # How many consecutive failures
        self._rpm_timestamps = []     # Timestamps of requests this minute
        self._rpd_count = 0           # Requests today
        self._rpd_reset_day = None    # Day of last RPD reset
        self._cache = {}              # Simple response cache
        self._cache_max = 50          # Max cached responses

    def _reset_rpd_if_needed(self):
        """Reset daily counter at midnight."""
        today = time.localtime().tm_yday
        if self._rpd_reset_day != today:
            self._rpd_count = 0
            self._rpd_reset_day = today

    def _cleanup_rpm(self):
        """Remove timestamps older than 60 seconds."""
        now = time.time()
        self._rpm_timestamps = [t for t in self._rpm_timestamps if now - t < 60]

    @property
    def current_rpm(self):
        """Current requests in the last 60 seconds."""
        self._cleanup_rpm()
        return len(self._rpm_timestamps)

    @property
    def is_cooling_down(self):
        """Check if we're in a cooldown period."""
        return time.time() < self._cooldown_until

    @property
    def cooldown_remaining(self):
        """Seconds remaining in cooldown."""
        remaining = self._cooldown_until - time.time()
        return max(0, int(remaining))

    def can_make_request(self):
        """Check if we can make a request without hitting limits."""
        if not GEMINI_API_KEY or not client:
            return False
        if self.is_cooling_down:
            return False
        self._reset_rpd_if_needed()
        if self._rpd_count >= self.RPD_LIMIT:
            return False
        if self.current_rpm >= self.RPM_SAFE:
            return False
        # Check internet connectivity
        import socket
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=2)
            return True
        except OSError:
            return False

    def record_request(self):
        """Record that a request was made."""
        self._rpm_timestamps.append(time.time())
        self._reset_rpd_if_needed()
        self._rpd_count += 1

    def record_success(self):
        """Record a successful response — reset backoff."""
        self._backoff_level = 0

    def record_rate_limit(self):
        """Record a rate limit error — enter cooldown with exponential backoff."""
        self._backoff_level = min(self._backoff_level + 1, 5)
        cooldown_seconds = 60 * (2 ** (self._backoff_level - 1))  # 60, 120, 240, 480, 960
        self._cooldown_until = time.time() + cooldown_seconds
        print(f"  [Gemini rate limited — cooldown {cooldown_seconds}s (backoff level {self._backoff_level})]")

    def record_error(self):
        """Record a non-rate-limit error — short cooldown."""
        self._cooldown_until = time.time() + 30  # 30 second cooldown for other errors

    def check_cache(self, key):
        """Check if we have a cached response."""
        return self._cache.get(key)

    def store_cache(self, key, value):
        """Store a response in cache (LRU eviction)."""
        if len(self._cache) >= self._cache_max:
            # Remove oldest entry
            oldest = next(iter(self._cache))
            del self._cache[oldest]
        self._cache[key] = value

    def trim_context(self, messages: list) -> list:
        """
        Trim message history to save tokens.
        Always keeps: system prompt + last N messages.
        """
        if len(messages) <= self.MAX_CONTEXT_MESSAGES:
            return messages

        # Find system messages
        system_msgs = [m for m in messages if m.get("role") == "system"]
        non_system = [m for m in messages if m.get("role") != "system"]

        # Keep last N non-system messages
        trimmed = non_system[-self.MAX_CONTEXT_MESSAGES:]

        return system_msgs + trimmed

    def status(self) -> str:
        """Return human-readable status."""
        if self.is_cooling_down:
            return f"cooling down ({self.cooldown_remaining}s remaining)"
        if self._rpd_count >= self.RPD_LIMIT:
            return "daily limit reached"
        return f"available (RPM: {self.current_rpm}/{self.RPM_LIMIT}, RPD: {self._rpd_count}/{self.RPD_LIMIT})"


# Global instance
_gemini = _GeminiManager()


# ── Backwards-compatible functions ───────────────────────────────────────────
def is_gemini_available() -> bool:
    """Check if Gemini can be used right now (with smart rate limiting)."""
    return _gemini.can_make_request()


def mark_quota_exceeded():
    """Record a rate limit hit (auto-recovers after cooldown)."""
    _gemini.record_rate_limit()


# ── Vision model detection ──────────────────────────────────────────────────
_VISION_MODELS = [
    "llava", "llava:latest", "llava:7b", "llava:13b", "llava:34b",
    "llava-llama3", "llava-llama3:latest",
    "bakllava", "bakllava:latest",
    "llava-phi3", "llava-phi3:latest",
    "minicpm-v", "minicpm-v:latest",
    "moondream", "moondream:latest", "moondream2",
    "llava-v1.6", "llava-v1.6-vicuna", "llava-v1.6-mistral",
    "xgen-mm", "fuyu", "cogvlm",
]


def get_available_models():
    """Get list of locally available Ollama models."""
    try:
        models_info = ollama.list()
        if hasattr(models_info, 'models'):
            models_list = models_info.models
        elif isinstance(models_info, dict):
            models_list = models_info.get('models', [])
        else:
            models_list = []
        names = []
        for m in models_list:
            if hasattr(m, 'model'):
                names.append(m.model)
            elif isinstance(m, dict):
                names.append(m.get('model', m.get('name', '')))
        return [n for n in names if n]
    except Exception as e:
        print(f"  [Warning: Could not list Ollama models: {e}]")
        return []


def _find_vision_model():
    """Find a suitable vision model from locally installed Ollama models."""
    available = get_available_models()
    if not available:
        return None
    # Tier 1: Exact match
    for vm in _VISION_MODELS:
        if vm in available:
            return vm
    # Tier 2: Base name match
    available_bases = {}
    for m in available:
        base = m.split(':')[0]
        available_bases[base] = m
    for vm in _VISION_MODELS:
        base = vm.split(':')[0]
        if base in available_bases:
            return available_bases[base]
    # Tier 3: Fuzzy keyword match
    vision_keywords = ['llava', 'vision', 'bakllava', 'moondream', 'minicpm-v', 'xgen-mm']
    for m in available:
        lower = m.lower()
        for kw in vision_keywords:
            if kw in lower:
                return m
    return None


def has_vision_model():
    """Check if a local Ollama vision model is available."""
    return _find_vision_model() is not None


# ── Simple / Complex patterns ───────────────────────────────────────────────
SIMPLE_PATTERNS = [
    "what time", "what's the time", "current time", "date today",
    "what day", "hello", "hi ", "hey ", "who are you", "your name",
    "what model", "what are you", "status", "help", "who built",
    "who made", "who created", "who is your"
]

COMPLEX_KEYWORDS = [
    "analyze", "write", "explain", "compare", "summarize",
    "code", "debug", "plan", "research", "essay", "report",
    "translate", "review", "generate", "describe", "elaborate"
]


# ── Ollama Chat ────────────────────────────────────────────────────────────
def chat_ollama(messages: list) -> str:
    """Always use Ollama — for tool reasoning steps."""
    try:
        clean = [{"role": m["role"], "content": m["content"]} for m in messages]
        response = ollama.chat(model=MODEL_OLLAMA, messages=clean)
        if hasattr(response, 'message') and hasattr(response.message, 'content'):
            return (response.message.content or '').strip()
        elif isinstance(response, dict):
            return response.get('message', {}).get('content', '').strip()
        return str(response).strip()
    except Exception as e:
        return f"Ollama error: {e}"


# ── Gemini Chat (with rate limiter + caching + context trim) ────────────────
def chat_gemini(messages: list) -> str:
    """Use Gemini — only for final answers on complex tasks. Smart rate-limited."""
    if not is_gemini_available():
        if _gemini.is_cooling_down:
            print(f"  [Gemini cooling down ({_gemini.cooldown_remaining}s) — using Ollama]")
        return chat_ollama(messages)

    # Trim context to save tokens
    trimmed = _gemini.trim_context(messages)

    # Check cache
    cache_key = str(hash(str(trimmed)))
    cached = _gemini.check_cache(cache_key)
    if cached:
        print("  [Gemini cache hit — no API call needed]")
        return cached

    try:
        _gemini.record_request()

        system_text = ""
        history = []
        for m in trimmed:
            if m["role"] == "system":
                system_text = m["content"]
            elif m["role"] == "user":
                history.append(types.Content(
                    role="user",
                    parts=[types.Part(text=m["content"])]
                ))
            elif m["role"] == "assistant":
                history.append(types.Content(
                    role="model",
                    parts=[types.Part(text=m["content"])]
                ))
        if not history:
            return chat_ollama(messages)
        last_content = history[-1].parts[0].text
        prior_history = history[:-1]
        config = types.GenerateContentConfig(
            system_instruction=system_text if system_text else None,
            max_output_tokens=_GeminiManager.MAX_OUTPUT_TOKENS,
        )
        session = client.chats.create(
            model=MODEL_GEMINI,
            history=prior_history,
            config=config,
        )
        response = session.send_message(last_content)
        result = response.text.strip()

        _gemini.record_success()
        _gemini.store_cache(cache_key, result)
        print(f"  [Gemini OK — RPM: {_gemini.current_rpm}, RPD: {_gemini._rpd_count}]")
        return result

    except Exception as e:
        err = str(e)
        if "429" in err or "quota" in err.lower() or "exhausted" in err.lower():
            _gemini.record_rate_limit()
            return chat_ollama(messages)
        else:
            _gemini.record_error()
            print(f"  [Gemini error: {err[:120]}]")
            return chat_ollama(messages)


# ── Chat Router ────────────────────────────────────────────────────────────
def chat(messages: list, mode: str = DEFAULT_MODE) -> str:
    if mode == "ollama":
        return chat_ollama(messages)
    if mode == "gemini":
        return chat_gemini(messages)
    return chat_ollama(messages)


def should_use_gemini_for_final(user_input: str, mode: str) -> bool:
    """Decide if Gemini should polish the final answer."""
    if mode == "ollama":
        return False
    if not is_gemini_available():
        return False
    last = user_input.lower()
    if any(p in last for p in SIMPLE_PATTERNS):
        return False
    if mode == "gemini":
        return True
    return any(k in last for k in COMPLEX_KEYWORDS)


# ── Vision (Image Analysis) ────────────────────────────────────────────────
import re as _re

_BLIND_PHRASES = [
    "i don't actually see", "i cannot see", "i can't see",
    "i am unable to see", "no image is visible", "there is no image",
    "i'm not able to see", "i am not able to see", "i don't see an image",
    "i don't see any image", "no visual content", "no image present",
    "i'm a text-based", "i'm a text only", "text-only model",
    "cannot process images", "cannot view images", "cannot see images",
]


def _clean_vision_output(text: str) -> str:
    """Remove garbage tokens like <unk> from LLaVA output."""
    text = _re.sub(r'<unk>', '', text)
    text = _re.sub(r'<[a-z]+>', '', text)
    text = _re.sub(r'\s+', ' ', text).strip()
    lines = text.split('\n')
    lines = [l for l in lines if l.strip() and not _re.match(r'^[\s\W]+$', l)]
    return '\n'.join(lines).strip()


def _is_blind_response(text: str) -> bool:
    """Check if the model claims it can't see the image."""
    lower = text.lower()
    return any(phrase in lower for phrase in _BLIND_PHRASES)


def _prepare_images(images: list) -> list:
    """Extract clean base64 strings from image dicts."""
    b64_list = []
    for img in images:
        b64 = img.get('base64', '')
        if b64.startswith('data:'):
            b64 = b64.split(',', 1)[-1]
        b64_list.append(b64)
    return b64_list


def _try_ollama_vision(text: str, images: list) -> str:
    """Send text + images to an Ollama vision model (e.g., llava)."""
    vision_model = _find_vision_model()
    if not vision_model:
        raise RuntimeError("No Ollama vision model found. Install one with: ollama pull llava")

    b64_images = _prepare_images(images)
    if not b64_images:
        raise RuntimeError("No valid image data provided")

    print(f"  [Ollama Vision: using {vision_model} with {len(b64_images)} image(s), ~{len(b64_images[0])//1024}KB]")

    system_prompt = (
        "You are a helpful vision assistant. The user has shared an image with you. "
        "You CAN see and analyze this image. Describe what you see in detail. "
        "Do NOT say you cannot see the image — the image is attached to your input. "
        "Provide a thorough, accurate description of the visual content."
    )

    # Strategy 1: ollama.chat()
    try:
        response = ollama.chat(
            model=vision_model,
            messages=[
                {'role': 'system', 'content': system_prompt},
                {
                    'role': 'user',
                    'content': text if text else "Describe this image in detail.",
                    'images': b64_images
                }
            ]
        )
        content = ''
        if hasattr(response, 'message') and hasattr(response.message, 'content'):
            content = response.message.content or ''
        elif isinstance(response, dict):
            content = response.get('message', {}).get('content', '')
        content = content.strip()
        content = _clean_vision_output(content)

        if content and not _is_blind_response(content):
            print(f"  [Ollama Vision: chat() OK — {len(content)} chars]")
            return content
        else:
            print(f"  [Ollama Vision: chat() returned blind/empty, trying generate()]")
    except Exception as e:
        print(f"  [Ollama Vision: chat() failed ({e}), trying generate()]")

    # Strategy 2: ollama.generate()
    try:
        response = ollama.generate(
            model=vision_model,
            prompt=text if text else "Describe this image in detail.",
            images=b64_images,
            system=system_prompt,
        )
        content = ''
        if hasattr(response, 'response'):
            content = response.response or ''
        elif isinstance(response, dict):
            content = response.get('response', '')
        content = content.strip()
        content = _clean_vision_output(content)

        if content and not _is_blind_response(content):
            print(f"  [Ollama Vision: generate() OK — {len(content)} chars]")
            return content
        else:
            print(f"  [Ollama Vision: generate() also returned blind/empty]")
    except Exception as e:
        print(f"  [Ollama Vision: generate() also failed ({e})")

    raise RuntimeError(
        f"Ollama vision model ({vision_model}) did not properly analyze the image. "
        f"Try restarting Ollama or using a different image format."
    )


def chat_with_images(text: str, images: list) -> str:
    """
    Send text + images to vision models.
    Priority: Ollama Vision → Gemini Vision → text-only fallback
    """
    # Attempt 1: Ollama Vision
    try:
        return _try_ollama_vision(text, images)
    except Exception as e:
        print(f"  [Ollama Vision failed: {e}]")

    # Attempt 2: Gemini Vision
    if is_gemini_available():
        try:
            import base64 as _b64
            _gemini.record_request()
            parts = []
            for img in images:
                raw_b64 = img.get('base64', '')
                if raw_b64.startswith('data:'):
                    raw_b64 = raw_b64.split(',', 1)[-1]
                parts.append(types.Part(
                    inline_data=types.Blob(
                        mime_type=img.get('mime', 'image/jpeg'),
                        data=_b64.b64decode(raw_b64)
                    )
                ))
            parts.append(types.Part(text=text))
            response = client.models.generate_content(
                model=MODEL_GEMINI,
                contents=[types.Content(role="user", parts=parts)],
                config=types.GenerateContentConfig(
                    max_output_tokens=_GeminiManager.MAX_OUTPUT_TOKENS,
                ),
            )
            result = response.text.strip()
            _gemini.record_success()
            return result
        except Exception as e:
            err = str(e)
            if "429" in err or "quota" in err.lower():
                _gemini.record_rate_limit()
            else:
                _gemini.record_error()
            print(f"  [Gemini Vision error: {err[:120]}]")

    # Fallback
    vision_model_name = _find_vision_model()
    if vision_model_name:
        return (
            f"I can see you've shared an image! Unfortunately, both Ollama vision "
            f"({vision_model_name}) and Gemini Vision failed to process it.\n\n"
            f"Please try again or describe the image in text."
        )
    else:
        return (
            f"I can see you've shared an image! Unfortunately, I couldn't analyze it because:\n\n"
            f"1. No Ollama vision model is installed\n"
            f"2. Gemini Vision is currently unavailable\n\n"
            f"To enable image analysis, install a vision model:\n"
            f"  ollama pull llava\n\n"
            f"Then restart Aria."
        )
