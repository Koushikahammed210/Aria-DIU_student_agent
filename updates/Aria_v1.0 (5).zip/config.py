import os
from dotenv import load_dotenv
load_dotenv()

MODEL_OLLAMA = "llama3.1:8b"
MODEL_GEMINI = "gemini-2.0-flash"
OLLAMA_BASE_URL = "http://localhost:11434"
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

MAX_ITERATIONS = 15
MAX_HISTORY = 40
SEARCH_MAX_RESULTS = 5
MEMORY_FILE = "memory.json"
AGENT_NAME = "Aria"

# "ollama", "gemini", or "auto"
DEFAULT_MODE = "auto"