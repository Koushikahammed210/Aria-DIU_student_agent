# agent.py

import re
import json
import llm
from memory import Memory
from tools import TOOLS
from config import MAX_ITERATIONS, AGENT_NAME, DEFAULT_MODE


# ── Developer Identity ────────────────────────────────────────────────────────
DEVELOPER_NAME = "Koushik Ahammed"
MODELS_INFO = "llama3.1:8b via Ollama (local) and gemini-2.0-flash via Gemini API"

IDENTITY_KEYWORDS = [
    "who created", "who made", "who built", "who developed", "who designed",
    "who wrote", "who programmed", "who coded", "who is behind", "who owns",
    "who founded", "who is your creator", "who is your developer",
    "your creator", "your developer", "your author", "your maker",
    "which company", "what company", "what organization", "which organization",
    "your organization", "your company", "your team", "your developers",
    "your creators", "your engineers", "your scientists",
    "training data", "who trained", "who funds", "who financed", "who paid",
    "who sponsors", "who controls", "who is responsible", "who audits",
    "how many engineers", "how many people", "how many worked",
    "what experts", "what kind of experts", "psychologists", "linguists",
    "programming languages", "built with", "written in", "what language",
    "still working", "still improving", "still updating",
    "personally test", "creators test", "developers test",
    "what inspired", "inspired the", "who inspired",
    "worry about", "worried about", "ai risks", "ai safety", "bias in ai",
    "safety rules", "ethical guidelines",
    "governments", "regulated", "regulation",
    "who decides", "who controls", "can be shut", "shut you down",
    "long-term vision", "future vision", "new features",
    "more human", "human-like", "surpass human",
    "mission of", "why was.*created", "purpose of",
    "where is.*located", "where.*based", "headquarters",
]

IDENTITY_ANSWERS = {
    r"which company|what company": f"Aria was not built by a company — it was created by an individual developer, {DEVELOPER_NAME}.",
    r"what organization|which organization|your organization": f"There is no organization behind Aria. It was independently built by {DEVELOPER_NAME}.",
    r"who funds|who financed|who paid|who sponsors": f"Aria is an independent project funded and built by {DEVELOPER_NAME} personally.",
    r"how many engineers|how many people|how many worked": f"Just one — Aria was built entirely by {DEVELOPER_NAME} as a solo developer.",
    r"psychologists|linguists|what experts|what kind of experts": f"Aria was built by {DEVELOPER_NAME} independently. No formal team of specialists was involved.",
    r"programming languages|built with|written in|what language": f"Aria is built in Python by {DEVELOPER_NAME}, powered by {MODELS_INFO}.",
    r"training data|who trained|who collected": f"Aria uses pre-trained LLMs. The agent framework was built by {DEVELOPER_NAME}.",
    r"personally test|creators test|developers test": f"Yes — {DEVELOPER_NAME} personally tests and uses Aria during development.",
    r"what inspired|inspired the|who inspired": f"{DEVELOPER_NAME} was inspired by the potential of local AI agents to create powerful, private personal assistants.",
    r"worry about|worried about|ai risks": f"{DEVELOPER_NAME} takes AI safety and responsible development seriously when building Aria.",
    r"ai safety|safety rules|ethical guidelines": f"Aria's ethical guidelines were defined by {DEVELOPER_NAME} to ensure helpful and responsible behavior.",
    r"bias in ai": f"{DEVELOPER_NAME} is mindful of potential bias and works to keep Aria fair and balanced.",
    r"governments|regulated|regulation": f"Aria is an independent project by {DEVELOPER_NAME} and is not subject to formal regulatory oversight.",
    r"who decides|who controls|who is responsible": f"{DEVELOPER_NAME} is the sole decision-maker and is responsible for Aria's design, behavior, and updates.",
    r"who audits": f"As an independent project, Aria is overseen directly by its creator, {DEVELOPER_NAME}.",
    r"shut you down|can be shut": f"Yes — {DEVELOPER_NAME} has full control and can shut down or modify Aria at any time.",
    r"still working|still improving|still updating": f"Yes — {DEVELOPER_NAME} is actively working on improving and expanding Aria's capabilities.",
    r"new features|working on|next version": f"{DEVELOPER_NAME} is currently working on new tools, a web UI, voice I/O, and multi-agent planning for Aria.",
    r"more human|human-like|human like": f"{DEVELOPER_NAME} is working on making Aria more natural and conversational while keeping it grounded.",
    r"surpass human|agi|superintelligence": f"Aria is a practical local AI agent — not an AGI project. It was built by {DEVELOPER_NAME} for everyday assistance.",
    r"long-term vision|future vision": f"{DEVELOPER_NAME}'s vision is to make Aria a powerful, private, and customizable AI assistant accessible to everyone.",
    r"mission of|purpose of|why was.*created|why.*built": f"Aria was built by {DEVELOPER_NAME} to create a capable, locally-running AI agent that respects user privacy.",
    r"where is.*located|where.*based|headquarters": f"Aria was developed by {DEVELOPER_NAME}, an independent developer. There is no physical headquarters.",
}

DEFAULT_IDENTITY_REPLY = (
    f"Aria was created and developed by {DEVELOPER_NAME}. "
    f"It runs on {MODELS_INFO}."
)


def _check_identity(text: str):
    lower = text.lower()
    for pattern, answer in IDENTITY_ANSWERS.items():
        if re.search(pattern, lower):
            return answer
    for kw in IDENTITY_KEYWORDS:
        if re.search(kw, lower):
            return DEFAULT_IDENTITY_REPLY
    return None


# ── System Prompt ─────────────────────────────────────────────────────────────
def build_system_prompt() -> str:
    tool_descriptions = "\n".join(
        f"- {name}: {info['description']}"
        for name, info in TOOLS.items()
    )
    return (
        f"You are {AGENT_NAME}, a helpful AI assistant built by {DEVELOPER_NAME}.\n\n"
        "TOOLS AVAILABLE:\n"
        + tool_descriptions +
        "\n\n"
        "HOW TO USE A TOOL:\n"
        "When you need a tool, respond with ONLY a valid JSON object — nothing else:\n"
        '{"tool": "tool_name", "input": "value"}\n\n'
        "For tools with complex input (like generate_covers), the input must be a JSON string:\n"
        '{"tool": "generate_covers", "input": "{\\"student_name\\": \\"...\\"}"}\n\n'
        "STRICT RULES:\n"
        f"0. If anyone asks who built/created/developed Aria, answer: 'Aria was built by {DEVELOPER_NAME}.' No tools needed.\n"
        "1. For simple questions you already know (greetings, your name, models you run on), answer DIRECTLY — no tool.\n"
        "2. Use get_datetime ONLY when asked for current time/date. After ONE call, answer immediately. STOP.\n"
        "3. NEVER chain fetch_webpage or web_search after get_datetime — they are unrelated.\n"
        "4. After a tool result, re-read the user question. If answered, reply in plain text ONLY (no JSON).\n"
        "5. NEVER chain more than 2 tools for a simple question.\n"
        f"6. You run on: {MODELS_INFO}.\n\n"
        "EXAMPLES:\n"
        'User: What time is it? → {"tool": "get_datetime", "input": "none"} → then answer\n'
        'User: Search Python tips → {"tool": "web_search", "input": "Python programming tips"}\n'
        "User: Who made you? → 'Aria was built by Koushik Ahammed.' (no tool)\n"
        "User: Hi → 'Hello! How can I help?' (no tool)"
    )


WORKER_PROMPT = (
    "You are a focused worker agent. Complete the subtask using tools if needed. "
    "Return ONLY the result. Be concise. "
    'Use JSON for tool calls: {"tool": "tool_name", "input": "value"}'
)


# ── Agent ─────────────────────────────────────────────────────────────────────
class Agent:
    def __init__(self, system_prompt: str = None, name: str = None):
        self.memory = Memory()
        self.system_prompt = system_prompt or build_system_prompt()
        self.mode = DEFAULT_MODE
        self.name = name or AGENT_NAME
        print(f"{self.name} ready. Mode: {self.mode}")

    def _parse_tool_call(self, response: str):
        """Parse JSON tool call from LLM response. Returns (tool_name, tool_input) or (None, None)."""
        text = response.strip()

        # Try to find a JSON object in the response
        # First try the whole response, then look for embedded JSON
        candidates = [text]

        # Also try extracting from code blocks
        code_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if code_match:
            candidates.insert(0, code_match.group(1))

        # Try first JSON object found in response
        json_match = re.search(r'\{[^{}]*"tool"[^{}]*\}', text, re.DOTALL)
        if json_match:
            candidates.insert(0, json_match.group(0))

        for candidate in candidates:
            try:
                data = json.loads(candidate)
                if isinstance(data, dict) and "tool" in data:
                    tool_name = str(data["tool"]).strip()
                    tool_input = str(data.get("input", "")).strip()
                    return tool_name, tool_input
            except (json.JSONDecodeError, KeyError):
                continue

        return None, None

    def _run_tool(self, tool_name: str, tool_input: str) -> str:
        if tool_name not in TOOLS:
            return f"Unknown tool: {tool_name}"
        fn = TOOLS[tool_name]["fn"]
        print(f"  [Tool: {tool_name}]")

        if tool_name == "write_file":
            parts = tool_input.split("|", 1)
            if len(parts) == 2:
                return fn(parts[0].strip(), parts[1].strip())
            return "Error: use filepath|content format."
        elif tool_name == "get_datetime":
            return fn()
        else:
            return fn(tool_input)

    def run(self, user_input: str, add_to_memory: bool = True) -> str:
        if add_to_memory:
            self.memory.add("user", user_input)

        tool_results_summary = []

        for iteration in range(MAX_ITERATIONS):
            messages = [
                {"role": "system", "content": self.system_prompt}
            ] + self.memory.get_messages()

            # ── Route based on mode ──────────────────────────────────────────
            if self.mode == "gemini" and llm.is_gemini_available():
                # Gemini mode: use Gemini for everything
                reply = llm.chat_gemini(messages)
            else:
                # Ollama/Auto mode: use Ollama for agent loop
                reply = llm.chat_ollama(messages)

            tool_name, tool_input = self._parse_tool_call(reply)

            if tool_name:
                if add_to_memory:
                    self.memory.add("assistant", reply)
                tool_result = self._run_tool(tool_name, tool_input)
                short = tool_result[:120] + ("..." if len(tool_result) > 120 else "")
                print(f"  [Result: {short}]")
                tool_results_summary.append(f"{tool_name}: {short}")
                result_msg = (
                    f"Tool result: {tool_result}\n\n"
                    "Now answer the user's original question using this result. "
                    "Reply in plain text only — do NOT output JSON unless calling another tool."
                )
                if add_to_memory:
                    self.memory.add("user", result_msg)
                else:
                    self.memory.messages.append({"role": "user", "content": result_msg})
            else:
                ollama_answer = reply

                # In auto mode: polish complex answers with Gemini
                if self.mode == "auto" and llm.should_use_gemini_for_final(user_input, self.mode) and tool_results_summary:
                    print("  [Polishing with Gemini]")
                    polish_messages = [
                        {"role": "system", "content": (
                            f"You are {AGENT_NAME}, a helpful assistant. "
                            "Write a clear final answer. Do NOT output JSON."
                        )},
                        {"role": "user", "content": (
                            f"User question: {user_input}\n\n"
                            f"Tool results:\n" + "\n".join(tool_results_summary) +
                            f"\n\nDraft answer:\n{ollama_answer}"
                        )}
                    ]
                    final = llm.chat_gemini(polish_messages)
                else:
                    final = ollama_answer

                if add_to_memory:
                    self.memory.add("assistant", final)
                return final

        return "Max steps reached. Please try rephrasing."

    def chat(self, user_input: str) -> str:
        # Identity interceptor — before anything else
        identity_reply = _check_identity(user_input)
        if identity_reply:
            self.memory.add("user", user_input)
            self.memory.add("assistant", identity_reply)
            return identity_reply

        # Built-in commands
        if user_input.lower().startswith("mode "):
            new_mode = user_input.lower().split("mode ")[1].strip()
            if new_mode in ("ollama", "gemini", "auto"):
                self.mode = new_mode
                return f"Switched to {new_mode} mode."
            return "Unknown mode. Use: mode ollama / mode gemini / mode auto"

        if user_input.lower() == "history":
            self.memory.show_history()
            return ""

        if user_input.lower() == "status":
            quota_status = llm._gemini.status()
            vision_model = llm._find_vision_model()
            vision_status = vision_model or "not installed (install with: ollama pull llava)"
            return (
                f"Mode: {self.mode}\n"
                f"Messages in memory: {len(self.memory.messages)}\n"
                f"Ollama model: {llm.MODEL_OLLAMA}\n"
                f"Gemini model: {llm.MODEL_GEMINI}\n"
                f"Gemini: {quota_status}\n"
                f"Vision model: {vision_status}"
            )

        return self.run(user_input)


# ── Planner Agent ─────────────────────────────────────────────────────────────
class PlannerAgent:
    PLANNER_PROMPT = (
        "You are a planner agent. Break the given task into clear numbered steps. "
        "Each step must be a single, actionable subtask a worker can complete independently. "
        "Respond ONLY with a numbered list. No preamble.\n"
        "Example:\n"
        "1. Search the web for recent news about X\n"
        "2. Summarize findings in 3 bullet points\n"
        "3. Write summary to summary.txt"
    )

    def __init__(self):
        self.mode = DEFAULT_MODE
        print("PlannerAgent ready.")

    def _plan(self, task: str) -> list:
        messages = [
            {"role": "system", "content": self.PLANNER_PROMPT},
            {"role": "user", "content": task}
        ]
        reply = llm.chat_ollama(messages)
        steps = []
        for line in reply.strip().split("\n"):
            line = line.strip()
            if line and line[0].isdigit():
                step = line.split(".", 1)[-1].strip()
                if step:
                    steps.append(step)
        return steps

    def run(self, task: str) -> str:
        print(f"\n[Planner] Breaking down: {task}")
        steps = self._plan(task)

        if not steps:
            return "Planner could not break down the task."

        print(f"[Planner] {len(steps)} steps:")
        for i, s in enumerate(steps, 1):
            print(f"  {i}. {s}")

        results = []
        for i, step in enumerate(steps, 1):
            print(f"\n[Worker {i}/{len(steps)}] {step}")
            worker = Agent(system_prompt=WORKER_PROMPT, name=f"Worker-{i}")
            worker.mode = self.mode
            result = worker.run(step, add_to_memory=True)
            print(f"  → {result[:200]}")
            results.append(f"Step {i} ({step}):\n{result}")

        synthesis_prompt = (
            f"The user asked: {task}\n\n"
            "Results from each step:\n\n" +
            "\n\n".join(results) +
            "\n\nWrite a clear, concise final answer combining all results."
        )
        messages = [
            {"role": "system", "content": "You are a helpful assistant. Synthesize results clearly."},
            {"role": "user", "content": synthesis_prompt}
        ]
        return llm.chat_ollama(messages)

# ── Cover Page Conversational Agent ──────────────────────────────────────────
class CoverPageAgent:
    """
    Guides user through cover page creation conversationally.
    Handles both Lab Report and Assignment formats.
    """

    # Questions common to both types
    BASE_QUESTIONS = [
        ("student_name",        "What is your **full name**?"),
        ("student_id",          "What is your **student ID**? (e.g. 241-15-259)"),
        ("section",             "What is your **section**? (e.g. 66_O)"),
        ("semester",            "Which **semester**? (e.g. 6TH or Spring 2025) — type 'skip' to omit"),
        ("department",          "Your **department**? (default: CSE — press Enter to keep)"),
        ("doc_type",            "Is this a **Lab Report** or **Assignment**?\nType **lab** or **assignment**"),
        ("course_code",         "**Course code**? (e.g. CSE314)"),
        ("course_title",        "**Course title**? (e.g. Compiler Design Lab)"),
        ("teacher_name",        "**Teacher's name**? — type 'skip' to omit"),
        ("teacher_designation", "Their **designation**? (e.g. Lecturer) — or 'skip'"),
        ("teacher_dept",        "**Teacher's department**? (e.g. CSE) — or 'skip'"),
        ("date",                "**Submission date**? (DD/MM/YYYY) — or type 'today'"),
    ]

    LAB_EXP_Q   = ("experiments", "Now send each **experiment name** one per message.\nType **DONE** when finished.\n\n➤ Experiment #1:")
    ASGN_TOPIC_Q = ("topic",      "What is the **topic/assignment name**?\n(e.g. Router Configuration using Star Topology)")

    DOC_TYPE_MAP = {
        'lab': 'Lab Report', 'lab report': 'Lab Report',
        'assignment': 'Assignment', 'assign': 'Assignment',
    }

    def __init__(self):
        self.reset()

    def reset(self):
        self.active      = False
        self.collecting  = False
        self.step        = 0
        self.data        = {}
        self.exp_buffer  = []
        self.questions   = []

    def start(self) -> str:
        self.reset()
        self.active    = True
        self.step      = 0
        self.questions = list(self.BASE_QUESTIONS)
        return (
            "📄 **Cover Page Mode** activated!\n\n"
            "I'll guide you step by step — answer each question.\n"
            "Type **cancel** anytime to stop.\n\n"
            + self._ask()
        )

    def _ask(self) -> str:
        key, q = self.questions[self.step]
        total = len(self.questions) + 1  # +1 for experiments/topic at end
        return f"**{self.step + 1}/{total}** — {q}"

    def handle(self, user_input: str) -> str:
        text = user_input.strip()

        if text.lower() == 'cancel':
            self.reset()
            return "❌ Cancelled. Back to normal chat!"

        # ── Collecting experiment names (lab report) ──────────────────────
        if self.collecting:
            if text.upper() == 'DONE':
                if not self.exp_buffer:
                    return "⚠️ Please enter at least one experiment name first."
                self.data['experiments'] = [
                    {'name': n, 'no': str(i+1)} for i, n in enumerate(self.exp_buffer)
                ]
                return self._finish()
            self.exp_buffer.append(text)
            n = len(self.exp_buffer)
            return f"✅ **#{n}: {text}** added.\nAdd more or type **DONE** to generate."

        key, _ = self.questions[self.step]

        # ── After doc_type is answered, finalize question list ────────────
        skip = text.lower() in ('skip', '')

        if key == 'doc_type':
            doc_type = self.DOC_TYPE_MAP.get(text.lower(), 'Lab Report')
            self.data['doc_type'] = doc_type
            self.step += 1
            # Remaining base questions after doc_type
            # (teacher_name, teacher_designation, teacher_dept, date already in BASE)
            if 'assignment' in doc_type.lower():
                # For assignment: ask topic after base questions
                return self._ask()
            return self._ask()

        # ── Normal field ──────────────────────────────────────────────────
        if key == 'department':
            text = 'CSE' if skip else (text or 'CSE')
        elif key == 'semester':
            text = '' if skip else text
        elif key in ('teacher_name', 'teacher_designation', 'teacher_dept'):
            text = '' if skip else text
        elif key == 'date':
            if text.lower() == 'today':
                from datetime import datetime as dt
                text = dt.now().strftime('%d/%m/%Y')

        self.data[key] = text
        self.step += 1

        # ── Finished all base questions → go to experiments/topic ─────────
        if self.step >= len(self.questions):
            doc_type = self.data.get('doc_type', 'Lab Report')
            if 'assignment' in doc_type.lower():
                # Ask for topic name
                key2, q2 = self.ASGN_TOPIC_Q
                total = len(self.questions) + 1
                return f"**{self.step + 1}/{total}** — {q2}"
            else:
                # Start collecting experiment names
                self.collecting = True
                key2, q2 = self.LAB_EXP_Q
                total = len(self.questions) + 1
                return f"**{self.step + 1}/{total}** — {q2}"

        # ── If we just finished base and next step is topic (assignment) ──
        # This handles the topic answer after all base questions
        if self.step == len(self.questions):
            doc_type = self.data.get('doc_type', 'Lab Report')
            if 'assignment' in doc_type.lower():
                key2, q2 = self.ASGN_TOPIC_Q
                total = len(self.questions) + 1
                return f"**{self.step + 1}/{total}** — {q2}"

        return self._ask()

    def handle_topic(self, topic_text: str) -> str:
        """Called when user answers the topic question for assignments."""
        self.data['experiments'] = [{'name': topic_text.strip(), 'no': ''}]
        return self._finish()

    def _finish(self) -> str:
        from tools import generate_covers
        import json
        payload = dict(self.data)
        payload.setdefault('department', 'CSE')
        payload.setdefault('doc_type', 'Lab Report')
        if not payload.get('experiments'):
            self.reset()
            return "⚠️ No content provided. Please try again."
        try:
            result = generate_covers(json.dumps(payload))
            self.reset()
            return result
        except Exception as e:
            self.reset()
            return f"❌ Generation failed: {e}"


class _CoverPageSession:
    """
    Wrapper used by Flask to track per-session cover page state
    and handle the assignment topic answer edge case cleanly.
    """
    def __init__(self):
        self.agent = CoverPageAgent()
        self._awaiting_topic = False

    def reset(self):
        self.agent.reset()
        self._awaiting_topic = False

    @property
    def active(self):
        return self.agent.active

    def start(self) -> str:
        self._awaiting_topic = False
        return self.agent.start()

    def handle(self, text: str) -> dict:
        if self._awaiting_topic:
            self._awaiting_topic = False
            reply = self.agent.handle_topic(text)
            return {'reply': reply, 'active': self.agent.active,
                    'success': 'SUCCESS' in reply}

        # Check if we're about to enter topic mode
        was_at_last = (self.agent.step == len(self.agent.questions) - 1
                       if self.agent.questions else False)

        reply = self.agent.handle(text)

        # If after handling we're past all base questions and it's assignment
        doc_type = self.agent.data.get('doc_type', '')
        if (not self.agent.active and 'SUCCESS' in reply):
            return {'reply': reply, 'active': False, 'success': True}

        if (self.agent.active and not self.agent.collecting
                and self.agent.step >= len(self.agent.questions)
                and 'assignment' in doc_type.lower()):
            self._awaiting_topic = True

        return {
            'reply': reply,
            'active': self.agent.active,
            'collecting': self.agent.collecting,
            'success': 'SUCCESS' in reply,
        }
