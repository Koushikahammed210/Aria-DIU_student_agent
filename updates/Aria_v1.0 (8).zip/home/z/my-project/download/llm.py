# llm.py - Smart router: Multi-Ollama model selection + Gemini Manager with Option A

import ollama
import time
import hashlib
import socket
from google import genai
from google.genai import types
from config import (
    MODEL_OLLAMA, MODEL_GEMINI, GEMINI_API_KEY, DEFAULT_MODE,
    OLLAMA_MODELS, TASK_MODEL_MAP, DEFAULT_OLLAMA_MODEL
)

client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

SIMPLE_PATTERNS = [
    "what time", "what's the time", "current time", "date today",
    "what day", "hello", "hi ", "hey ", "who are you", "your name",
    "what model", "what are you", "status", "help", "who built",
    "who made", "who created", "who is your"
]

COMPLEX_KEYWORDS = [
    "analyze", "write", "explain", "compare", "summarize",
    "code", "debug", "plan", "research", "essay", "report",
    "translate", "review", "generate", "describe", "elaborate"
]

# Task-type keywords for model routing
TASK_TYPE_KEYWORDS = {
    "code": ["code", "program", "function", "script", "debug", "fix code", "implement", "algorithm",
             "python", "javascript", "java", "cpp", "html", "css", "api", "database", "sql",
             "refactor", "compile", "syntax", "variable", "loop", "class", "method", "bug"],
    "reasoning": ["reason", "logic", "prove", "math", "calculate", "derive", "prove that",
                  "why does", "explain why", "what if", "analyze the", "evaluate",
                  "deduce", "infer", "conclude", "critical thinking", "philosophy"],
    "fast": ["quick", "simple", "fast", "briefly", "short", "just tell me", "what is",
             "define", "meaning of", "synonym", "translate"],
    "tutoring": ["teach", "learn", "understand", "explain", "tutorial", "lesson",
                 "example", "step by step", "how to", "guide me", "help me learn",
                 "i don't understand", "confused about", "clarify"],
    "creative": ["creative", "story", "poem", "write a", "imagine", "brainstorm",
                 "idea", "fiction", "novel", "lyrics", "creative writing"],
}


# ── Gemini Manager ────────────────────────────────────────────────────────────
class _GeminiManager:
    """
    Smart Gemini manager with:
    - RPM/RPD leaky-bucket rate tracking
    - Auto-recovery with exponential backoff (only on 429 errors)
    - NO cooldown after successful calls
    - LRU response cache
    - Context trimming for long conversations
    """

    def __init__(self):
        self._available = True
        self._cooldown_until = 0.0
        self._backoff_level = 0
        self._backoff_times = [60, 120, 240, 480]

        # Rate tracking — CONSERVATIVE limits (12 RPM, not 15, for safety headroom)
        self._rpm_count = 0
        self._rpm_window_start = time.time()
        self._rpd_count = 0
        self._rpd_window_start = time.time()
        self._rpm_limit = 12   # Google says 15, we use 12 for safety
        self._rpd_limit = 1500

        # Minimum interval between calls (5s = max 12/min)
        self._last_call_time = 0.0
        self._min_call_interval = 5.0  # seconds between Gemini calls

        # LRU cache
        self._cache = {}
        self._cache_order = []
        self._cache_max = 50

        # Startup grace: assume we might have quota from previous session
        # First 429 after fresh start gets longer initial cooldown
        self._successful_calls = 0
        self._startup_grace = True

    def is_available(self) -> bool:
        """Check if Gemini is available, with auto-recovery after cooldown."""
        now = time.time()

        # Still in cooldown?
        if not self._available:
            if now < self._cooldown_until:
                return False
            # Cooldown expired — auto-recover
            self._available = True
            print("  [Gemini auto-recovery — cooldown expired, trying again]")

        # Check API key
        if not GEMINI_API_KEY or not client:
            return False

        # Quick network check
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=2)
        except OSError:
            return False

        # Enforce minimum interval between calls
        elapsed = now - self._last_call_time
        if elapsed < self._min_call_interval:
            wait_needed = self._min_call_interval - elapsed
            print(f"  [Gemini rate throttle — {wait_needed:.1f}s until next call allowed]")
            return False

        # Check rate limits
        self._update_rate_counters()
        if self._rpm_count >= self._rpm_limit:
            return False
        if self._rpd_count >= self._rpd_limit:
            return False

        return True

    def _update_rate_counters(self):
        """Update RPM/RPD counters with sliding window."""
        now = time.time()

        # RPM window: 60 seconds
        if now - self._rpm_window_start >= 60:
            self._rpm_count = 0
            self._rpm_window_start = now

        # RPD window: 24 hours
        if now - self._rpd_window_start >= 86400:
            self._rpd_count = 0
            self._rpd_window_start = now

    def record_call(self):
        """Record a SUCCESSFUL Gemini API call. NO cooldown after success."""
        self._update_rate_counters()
        self._rpm_count += 1
        self._rpd_count += 1
        self._last_call_time = time.time()
        self._successful_calls += 1
        # Reset backoff on success — Gemini is healthy
        self._backoff_level = 0
        self._startup_grace = False  # We've confirmed Gemini works
        print(f"  [Gemini call recorded: RPM {self._rpm_count}/{self._rpm_limit}, RPD {self._rpd_count}/{self._rpd_limit}]")

    def mark_rate_limited(self):
        """Handle 429 rate limit with exponential backoff. Only called on 429."""
        # If this is our FIRST call attempt after startup (startup_grace),
        # it means the previous session consumed quota. Use longer initial cooldown.
        if self._startup_grace and self._successful_calls == 0:
            # We haven't made ANY successful call yet, and we got 429 immediately.
            # This means quota from the previous session is still active on Google's side.
            backoff = 120  # Wait 2 minutes instead of 60s
            print(f"  [Gemini 429 on first attempt — previous session quota still active. Long cooldown {backoff}s]")
        else:
            backoff = self._backoff_times[min(self._backoff_level, len(self._backoff_times) - 1)]
            print(f"  [Gemini 429 rate limited — cooldown {backoff}s, backoff level {self._backoff_level + 1}]")

        self._available = False
        self._cooldown_until = time.time() + backoff
        self._backoff_level += 1

    def mark_overloaded(self):
        """Handle 503 overload with short cooldown."""
        self._available = False
        self._cooldown_until = time.time() + 30
        print("  [Gemini 503 overloaded — cooldown 30s]")

    def mark_invalid_key(self):
        """Handle 403 — invalid key. Long cooldown."""
        self._available = False
        self._cooldown_until = time.time() + 3600
        print("  [Gemini 403 invalid key — disabled for 1 hour]")

    def get_status(self) -> dict:
        """Get current status for /status endpoint and status command."""
        self._update_rate_counters()
        now = time.time()
        cooldown_remaining = max(0, int(self._cooldown_until - now)) if not self._available else 0

        if not self._available and cooldown_remaining > 0:
            state = "cooling down"
        elif not GEMINI_API_KEY:
            state = "no API key"
        elif self._rpm_count >= self._rpm_limit:
            state = "RPM limit reached"
        elif self._rpd_count >= self._rpd_limit:
            state = "RPD limit reached"
        else:
            state = "available"

        # Time until next call allowed
        now = time.time()
        next_call_in = max(0, self._min_call_interval - (now - self._last_call_time))

        return {
            "state": state,
            "available": self._available,
            "rpm": self._rpm_count,
            "rpm_limit": self._rpm_limit,
            "rpd": self._rpd_count,
            "rpd_limit": self._rpd_limit,
            "cooldown_remaining": cooldown_remaining,
            "backoff_level": self._backoff_level,
            "next_call_in": round(next_call_in, 1),
            "successful_calls": self._successful_calls,
        }

    def chat(self, messages: list) -> str:
        """
        Chat with Gemini with full error handling.
        Returns response string on success, None on failure (caller should fall back).
        """
        if not self.is_available():
            return None

        # Trim context for Gemini's window
        trimmed = self._trim_messages(messages, max_messages=10)

        # Check cache
        cache_key = self._make_cache_key(trimmed)
        cached = self._cache_get(cache_key)
        if cached is not None:
            print("  [Gemini cache hit!]")
            return cached

        try:
            system_text = ""
            contents = []
            for m in trimmed:
                if m["role"] == "system":
                    system_text = m["content"]
                elif m["role"] == "user":
                    contents.append(types.Content(
                        role="user",
                        parts=[types.Part(text=m["content"])]
                    ))
                elif m["role"] == "assistant":
                    contents.append(types.Content(
                        role="model",
                        parts=[types.Part(text=m["content"])]
                    ))

            if not contents:
                return None

            # Use models.generate_content() — SINGLE API call per message
            # This replaces chats.create() + send_message() which made 2+ calls
            # and was causing 429 rate limits to trigger much faster than expected
            config = types.GenerateContentConfig(
                system_instruction=system_text if system_text else None,
            )

            print(f"  [Gemini → generate_content() | {len(contents)} messages | model={MODEL_GEMINI}]")
            response = client.models.generate_content(
                model=MODEL_GEMINI,
                contents=contents,
                config=config,
            )
            result = response.text.strip()

            # SUCCESS — record the call (NO cooldown!)
            self.record_call()

            # Cache the response
            self._cache_set(cache_key, result)

            return result

        except Exception as e:
            err = str(e)
            if "429" in err or "quota" in err.lower() or "exhausted" in err.lower() or "RESOURCE_EXHAUSTED" in err:
                self.mark_rate_limited()
                return None
            if "503" in err or "overloaded" in err.lower():
                self.mark_overloaded()
                return None
            if "403" in err or "permission" in err.lower():
                self.mark_invalid_key()
                return None
            print(f"  [Gemini error: {e}]")
            return f"Gemini error: {e}"

    # ── Cache helpers ──────────────────────────────────────────────────────

    def _cache_get(self, key: str) -> str:
        if key in self._cache:
            self._cache_order.remove(key)
            self._cache_order.append(key)
            return self._cache[key]
        return None

    def _cache_set(self, key: str, value: str):
        if key in self._cache:
            self._cache_order.remove(key)
        self._cache[key] = value
        self._cache_order.append(key)
        while len(self._cache) > self._cache_max:
            oldest = self._cache_order.pop(0)
            del self._cache[oldest]

    @staticmethod
    def _trim_messages(messages: list, max_messages: int = 10) -> list:
        """Keep system prompt + last N messages."""
        if len(messages) <= max_messages + 1:
            return messages
        system_msgs = [m for m in messages if m["role"] == "system"]
        non_system = [m for m in messages if m["role"] != "system"]
        trimmed = non_system[-max_messages:]
        return system_msgs + trimmed

    @staticmethod
    def _make_cache_key(messages: list) -> str:
        """Hash last 3 messages for cache key."""
        content = "".join(m.get("content", "") for m in messages[-3:])
        return hashlib.md5(content.encode()).hexdigest()


# ── Global Gemini Manager instance ────────────────────────────────────────────
gemini_manager = _GeminiManager()


# ── Backward-compatible functions ────────────────────────────────────────────

def is_gemini_available() -> bool:
    """Check if Gemini is available (backward compat)."""
    return gemini_manager.is_available()


def mark_quota_exceeded():
    """Mark Gemini as rate-limited (backward compat)."""
    gemini_manager.mark_rate_limited()


def get_gemini_status() -> dict:
    """Get Gemini status info."""
    return gemini_manager.get_status()


# ── Model Selection ──────────────────────────────────────────────────────────

def select_best_model(user_input: str, persona: str = "default") -> str:
    """
    Intelligently select the best Ollama model based on:
    1. Active persona (tutor, coder, etc.) — HIGHEST priority
    2. User input content (task type detection) — only overrides for VERY EXPLICIT requests
    3. Task complexity
    """
    text = user_input.lower()

    persona_models = {
        "tutor": "qwen2.5:7b",
        "coder": "qwen2.5-coder:7b",
        "creative": "llama3:8b",
        "analyst": "deepseek-r1:8b",
    }

    preferred_model = persona_models.get(persona)

    best_task_type = None
    best_score = 0

    for task_type, keywords in TASK_TYPE_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text)
        if score > best_score:
            best_score = score
            best_task_type = task_type

    if preferred_model and preferred_model in OLLAMA_MODELS:
        persona_task_types = {
            "tutor": ["tutoring"],
            "coder": ["code"],
            "creative": ["creative"],
            "analyst": ["reasoning"],
        }
        persona_tasks = persona_task_types.get(persona, [])

        if best_task_type in persona_tasks:
            print(f"  [Model Router: {preferred_model} — persona: {persona} (task: {best_task_type}, score: {best_score})]")
            return preferred_model

        if best_score >= 5 and best_task_type:
            task_model = TASK_MODEL_MAP.get(best_task_type, DEFAULT_OLLAMA_MODEL)
            if task_model in OLLAMA_MODELS:
                print(f"  [Model Router: {task_model} — explicit task override: {best_task_type} (score: {best_score}, persona: {persona})]")
                return task_model

        print(f"  [Model Router: {preferred_model} — persona: {persona} (task: {best_task_type}, score: {best_score})]")
        return preferred_model

    if best_score >= 2 and best_task_type:
        task_model = TASK_MODEL_MAP.get(best_task_type, DEFAULT_OLLAMA_MODEL)
        if task_model in OLLAMA_MODELS:
            print(f"  [Model Router: {task_model} — task type: {best_task_type}]")
            return task_model

    print(f"  [Model Router: {DEFAULT_OLLAMA_MODEL} — default]")
    return DEFAULT_OLLAMA_MODEL


# ── Ollama Chat ──────────────────────────────────────────────────────────────

def _parse_ollama_response(response) -> str:
    """Parse Ollama response — handles both old dict and new pydantic formats."""
    try:
        # New ollama client (0.4.x+): pydantic objects
        if hasattr(response, 'message'):
            msg = response.message
            if hasattr(msg, 'content'):
                return msg.content.strip()
        # Old ollama client: dict
        if isinstance(response, dict):
            return response["message"]["content"].strip()
    except (KeyError, TypeError, AttributeError):
        pass
    # Last resort
    return str(response).strip()


def chat_ollama(messages: list, model: str = None) -> str:
    """Use Ollama with smart model selection."""
    try:
        use_model = model or MODEL_OLLAMA
        clean = [{"role": m["role"], "content": m["content"]} for m in messages]
        response = ollama.chat(model=use_model, messages=clean)
        return _parse_ollama_response(response)
    except Exception as e:
        err = str(e)
        if "not found" in err.lower() or "model" in err.lower():
            print(f"  [Model {use_model} not found, falling back to {DEFAULT_OLLAMA_MODEL}]")
            try:
                clean = [{"role": m["role"], "content": m["content"]} for m in messages]
                response = ollama.chat(model=DEFAULT_OLLAMA_MODEL, messages=clean)
                return _parse_ollama_response(response)
            except Exception as e2:
                return f"Ollama error: {e2}"
        return f"Ollama error: {e}"


# ── Gemini Chat (uses _GeminiManager) ────────────────────────────────────────

def chat_gemini(messages: list) -> str:
    """Use Gemini via _GeminiManager. Falls back to Ollama on failure."""
    result = gemini_manager.chat(messages)
    if result is not None:
        return result

    # Gemini unavailable — fall back to Ollama
    print("  [Gemini unavailable — falling back to Ollama]")
    return chat_ollama(messages)


# ── Main Chat Router ─────────────────────────────────────────────────────────

def chat(messages: list, mode: str = DEFAULT_MODE, model: str = None) -> str:
    """Route to the appropriate chat backend based on mode."""
    if mode == "gemini":
        return chat_gemini(messages)
    if mode == "ollama":
        return chat_ollama(messages, model=model)
    # auto mode: default to Ollama
    return chat_ollama(messages, model=model)


def should_use_gemini_for_final(user_input: str, mode: str) -> bool:
    """For auto mode: decide if Gemini should polish the final answer."""
    if mode == "ollama":
        return False
    if mode == "gemini":
        return True  # In gemini mode, always use Gemini
    if not is_gemini_available():
        return False
    last = user_input.lower()
    if any(p in last for p in SIMPLE_PATTERNS):
        return False
    return any(k in last for k in COMPLEX_KEYWORDS)


# ── Vision Model Detection & Image Analysis ──────────────────────────────────

_VISION_KEYWORDS = ["llava", "bakllava", "moondream", "minicpm-v", "llama3.2-vision"]


def get_available_models() -> list:
    """Get list of available Ollama model names (handles all ollama client versions)."""
    models = []

    # Method 1: ollama Python client
    try:
        models_resp = ollama.list()

        if hasattr(models_resp, 'models'):
            for m in models_resp.models:
                name = None
                for attr in ['model', 'name', 'id']:
                    val = getattr(m, attr, None)
                    if val and isinstance(val, str):
                        name = val
                        break
                if name:
                    models.append(name)
                else:
                    try:
                        name = m.get('name', m.get('model', ''))
                        if name:
                            models.append(name)
                    except:
                        pass

        elif isinstance(models_resp, dict):
            for m in models_resp.get('models', []):
                if isinstance(m, dict):
                    models.append(m.get('name', m.get('model', '')))
                elif isinstance(m, str):
                    models.append(m)
                elif hasattr(m, 'model'):
                    models.append(getattr(m, 'model', ''))
        else:
            try:
                for m in models_resp:
                    if isinstance(m, dict):
                        models.append(m.get('name', m.get('model', '')))
                    elif hasattr(m, 'model'):
                        models.append(getattr(m, 'model', ''))
                    elif hasattr(m, 'name'):
                        models.append(getattr(m, 'name', ''))
                    elif isinstance(m, str):
                        models.append(m)
            except TypeError:
                pass

        if models:
            return models

    except Exception as e:
        print(f"  [DEBUG] ollama.list() failed: {e}")

    # Method 2: Fallback to subprocess
    try:
        import subprocess
        result = subprocess.run(
            ['ollama', 'list'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                line = line.strip()
                if not line or line.startswith('NAME') or line.startswith('---'):
                    continue
                parts = line.split()
                if parts:
                    model_name = parts[0]
                    if model_name and model_name not in models:
                        models.append(model_name)
            if models:
                return models
    except Exception as e:
        print(f"  [DEBUG] `ollama list` CLI failed: {e}")

    # Method 3: Config fallback
    return list(OLLAMA_MODELS.keys())


def _find_vision_model(available: list) -> str:
    """Find the best available vision model. Returns model name or None."""
    known_vision = [
        "llava:latest", "llava", "llava:7b", "llava:13b",
        "llava-llama3:latest", "llava-llama3",
        "bakllava:latest", "bakllava",
        "moondream:latest", "moondream",
        "minicpm-v:latest", "minicpm-v",
        "llama3.2-vision:latest", "llama3.2-vision",
    ]

    # Tier 1: Exact match
    for vm in known_vision:
        if vm in available:
            return vm

    # Tier 2: Base name match
    for vm in known_vision:
        base_vm = vm.split(':')[0]
        for av in available:
            base_av = av.split(':')[0]
            if base_vm == base_av:
                return av

    # Tier 3: Keyword fuzzy match
    for av in available:
        av_lower = av.lower()
        for kw in _VISION_KEYWORDS:
            if kw in av_lower:
                return av

    return None


def _clean_vision_output(text: str) -> str:
    """Clean LLaVA output — remove <unk> tokens and artifacts."""
    import re
    # Remove <unk> tokens
    text = re.sub(r'<unk>', '', text)
    # Remove other special tokens
    text = re.sub(r'<[a-z_]+>', '', text)
    # Remove excessive whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _is_blind_response(text: str) -> bool:
    """Detect if LLaVA hallucinated 'I cannot see the image'."""
    lower = text.lower()
    blind_phrases = [
        "i cannot see", "i can't see", "i don't see", "i am unable to see",
        "no image", "cannot see any image", "can't see any image",
        "unable to process the image", "i'm not able to see",
        "i am a text", "i cannot process images", "as a text",
        "i cannot view", "i'm unable to view",
    ]
    return any(phrase in lower for phrase in blind_phrases)


def _try_ollama_vision(text: str, images: list) -> str:
    """
    Try Ollama vision models (llava, etc.) for image analysis.
    Returns result string or None if failed.
    """
    try:
        available = get_available_models()
        if not available:
            return None

        exact_model = _find_vision_model(available)
        if not exact_model:
            return None

        # Prepare image data
        ollama_images = []
        for img in images:
            img_data = img.get('base64', '')
            if img_data:
                ollama_images.append(img_data)

        if not ollama_images:
            return None

        # System prompt telling LLaVA it CAN see images (prevents hallucination)
        vision_system = (
            "You CAN see and analyze this image. Do NOT say you cannot see the image. "
            "Describe what you see in detail and answer the user's question."
        )

        print(f"  [Vision] Calling ollama.chat with model={exact_model}, {len(ollama_images)} image(s)")

        # Strategy 1: ollama.chat() with images
        try:
            response = ollama.chat(
                model=exact_model,
                messages=[
                    {"role": "system", "content": vision_system},
                    {"role": "user", "content": text, "images": ollama_images}
                ]
            )
            result = _parse_ollama_response(response)
            result = _clean_vision_output(result)
            if result and not _is_blind_response(result):
                print(f"  [Vision SUCCESS] Response length: {len(result)} chars")
                return result
            else:
                print("  [Vision] ollama.chat returned blind/empty response")
        except Exception as e:
            print(f"  [Vision] ollama.chat() failed: {e}")

        # Strategy 2: ollama.generate() fallback
        try:
            response = ollama.generate(
                model=exact_model,
                prompt=f"{vision_system}\n\n{text}",
                images=ollama_images
            )
            if isinstance(response, dict):
                result = response.get("response", "").strip()
            else:
                result = getattr(response, 'response', '').strip()
            result = _clean_vision_output(result)
            if result and not _is_blind_response(result):
                print(f"  [Vision SUCCESS via generate()] Response length: {len(result)} chars")
                return result
        except Exception as e:
            print(f"  [Vision] ollama.generate() also failed: {e}")

        return None

    except Exception as e:
        print(f"  [Vision ERROR] Unexpected: {e}")
        return None


def chat_with_images(text: str, images: list, mode: str = DEFAULT_MODE) -> str:
    """
    Send text + images for vision analysis.
    Order depends on mode:
    - gemini mode: Gemini Vision first → Ollama Vision → fallback
    - ollama/auto mode: Ollama Vision first → Gemini Vision → fallback
    images: list of {base64: str, mime: str}
    """
    print(f"  [Vision] chat_with_images called with {len(images)} image(s), mode={mode}")

    if mode == "gemini":
        # Gemini mode: try Gemini Vision first
        if gemini_manager.is_available():
            try:
                import base64
                parts = []
                for img in images:
                    parts.append(types.Part(
                        inline_data=types.Blob(
                            mime_type=img.get('mime', 'image/jpeg'),
                            data=base64.b64decode(img['base64'])
                        )
                    ))
                parts.append(types.Part(text=text))
                response = client.models.generate_content(
                    model=MODEL_GEMINI,
                    contents=[types.Content(role="user", parts=parts)]
                )
                gemini_manager.record_call()
                print(f"  [Vision SUCCESS] Gemini Vision responded")
                return response.text.strip()
            except Exception as e:
                err = str(e)
                if "429" in err or "quota" in err.lower() or "RESOURCE_EXHAUSTED" in err:
                    gemini_manager.mark_rate_limited()
                elif "503" in err or "overloaded" in err.lower():
                    gemini_manager.mark_overloaded()
                else:
                    print(f"  [Vision] Gemini error: {e}")
                print("  [Vision] Gemini Vision failed — falling back to Ollama vision")

        # Fallback to Ollama vision
        vision_result = _try_ollama_vision(text, images)
        if vision_result:
            return vision_result

    else:
        # Ollama/auto mode: try Ollama Vision first
        vision_result = _try_ollama_vision(text, images)
        if vision_result:
            return vision_result

        # Fallback to Gemini Vision
        if gemini_manager.is_available():
            try:
                import base64
                parts = []
                for img in images:
                    parts.append(types.Part(
                        inline_data=types.Blob(
                            mime_type=img.get('mime', 'image/jpeg'),
                            data=base64.b64decode(img['base64'])
                        )
                    ))
                parts.append(types.Part(text=text))
                response = client.models.generate_content(
                    model=MODEL_GEMINI,
                    contents=[types.Content(role="user", parts=parts)]
                )
                gemini_manager.record_call()
                print(f"  [Vision SUCCESS] Gemini Vision (fallback) responded")
                return response.text.strip()
            except Exception as e:
                err = str(e)
                if "429" in err or "quota" in err.lower() or "RESOURCE_EXHAUSTED" in err:
                    gemini_manager.mark_rate_limited()
                else:
                    print(f"  [Vision] Gemini Vision fallback error: {e}")

    # All vision methods failed
    print(f"  [Vision FAILED] All vision methods failed")
    return (
        "I can see you've shared an image! Unfortunately, I'm currently unable to analyze it directly because:\n\n"
        "- **Gemini Vision** is temporarily unavailable\n"
        "- **Ollama vision model** (like `llava`) could not process the image\n\n"
        "**How to fix this:**\n"
        "1. Run `ollama pull llava` in your terminal to install a local vision model\n"
        "2. **Restart the Aria server** after installing\n"
        "3. Check the server console for error messages\n\n"
        "**In the meantime:** If you can describe what's in the image, I can help with detailed text-based analysis!"
    )


# ── Health & Diagnostics ────────────────────────────────────────────────────

def check_ollama_health() -> dict:
    """Check which Ollama models are actually running/available."""
    result = {}
    try:
        available = get_available_models()
        for model_name in OLLAMA_MODELS:
            is_available = any(model_name in av for av in available)
            result[model_name] = {
                "available": is_available,
                "info": OLLAMA_MODELS[model_name],
            }
        vision_model = _find_vision_model(available)
        if vision_model and vision_model not in result:
            result[vision_model] = {
                "available": True,
                "info": {"strengths": ["vision", "image_analysis"], "category": "vision"},
            }
    except Exception as e:
        result["error"] = str(e)
    return result


def has_vision_model() -> bool:
    """Quick check if any Ollama vision model is available."""
    try:
        available = get_available_models()
        return _find_vision_model(available) is not None
    except:
        return False


def vision_diagnostic() -> dict:
    """Full diagnostic of vision model detection."""
    diag = {
        "step1_ollama_list": {},
        "step2_model_parsing": {},
        "step3_vision_detection": {},
        "step4_direct_test": {},
    }

    try:
        resp = ollama.list()
        diag["step1_ollama_list"]["type"] = type(resp).__name__
        diag["step1_ollama_list"]["has_models_attr"] = hasattr(resp, 'models')

        if hasattr(resp, 'models'):
            raw_models = []
            for m in resp.models:
                info = {"type": type(m).__name__}
                for attr in ['model', 'name', 'id', 'size', 'digest', 'modified_at']:
                    val = getattr(m, attr, "NOT_FOUND")
                    info[attr] = str(val) if val != "NOT_FOUND" else "NOT_FOUND"
                raw_models.append(info)
            diag["step1_ollama_list"]["models_detail"] = raw_models
        elif isinstance(resp, dict):
            diag["step1_ollama_list"]["raw"] = str(resp)[:2000]
    except Exception as e:
        diag["step1_ollama_list"]["error"] = str(e)

    try:
        models = get_available_models()
        diag["step2_model_parsing"]["models"] = models
        diag["step2_model_parsing"]["count"] = len(models)
    except Exception as e:
        diag["step2_model_parsing"]["error"] = str(e)

    try:
        models = get_available_models()
        vision = _find_vision_model(models)
        diag["step3_vision_detection"]["available_models"] = models
        diag["step3_vision_detection"]["vision_model_found"] = vision
        diag["step3_vision_detection"]["has_vision"] = vision is not None
    except Exception as e:
        diag["step3_vision_detection"]["error"] = str(e)

    try:
        models = get_available_models()
        vision = _find_vision_model(models)
        if vision:
            try:
                resp = ollama.chat(
                    model=vision,
                    messages=[{"role": "user", "content": "Say 'vision model working' in 3 words."}]
                )
                diag["step4_direct_test"]["model"] = vision
                diag["step4_direct_test"]["text_test"] = "SUCCESS"
                diag["step4_direct_test"]["response_preview"] = _parse_ollama_response(resp)[:200]
            except Exception as e:
                diag["step4_direct_test"]["model"] = vision
                diag["step4_direct_test"]["text_test"] = f"FAILED: {e}"
        else:
            diag["step4_direct_test"]["skipped"] = "No vision model found to test"
    except Exception as e:
        diag["step4_direct_test"]["error"] = str(e)

    return diag
