# llm.py - Smart router: Multi-Ollama model selection + Gemini for final answers

import ollama
from google import genai
from google.genai import types
from config import (
    MODEL_OLLAMA, MODEL_GEMINI, GEMINI_API_KEY, DEFAULT_MODE,
    OLLAMA_MODELS, TASK_MODEL_MAP, DEFAULT_OLLAMA_MODEL
)

client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

# Session-level quota tracker
_gemini_quota_exceeded = False
_gemini_quota_exceeded_at = None  # timestamp of when quota was hit

SIMPLE_PATTERNS = [
    "what time", "what's the time", "current time", "date today",
    "what day", "hello", "hi ", "hey ", "who are you", "your name",
    "what model", "what are you", "status", "help", "who built",
    "who made", "who created", "who is your"
]

COMPLEX_KEYWORDS = [
    "analyze", "write", "explain", "compare", "summarize",
    "code", "debug", "plan", "research", "essay", "report",
    "translate", "review", "generate", "describe", "elaborate"
]

# Task-type keywords for model routing
TASK_TYPE_KEYWORDS = {
    "code": ["code", "program", "function", "script", "debug", "fix code", "implement", "algorithm",
             "python", "javascript", "java", "cpp", "html", "css", "api", "database", "sql",
             "refactor", "compile", "syntax", "variable", "loop", "class", "method", "bug"],
    "reasoning": ["reason", "logic", "prove", "math", "calculate", "derive", "prove that",
                  "why does", "explain why", "what if", "analyze the", "evaluate",
                  "deduce", "infer", "conclude", "critical thinking", "philosophy"],
    "fast": ["quick", "simple", "fast", "briefly", "short", "just tell me", "what is",
             "define", "meaning of", "synonym", "translate"],
    "tutoring": ["teach", "learn", "understand", "explain", "tutorial", "lesson",
                 "example", "step by step", "how to", "guide me", "help me learn",
                 "i don't understand", "confused about", "clarify"],
    "creative": ["creative", "story", "poem", "write a", "imagine", "brainstorm",
                 "idea", "fiction", "novel", "lyrics", "creative writing"],
}


def is_gemini_available() -> bool:
    """Check if Gemini is available, with auto-recovery after quota reset."""
    global _gemini_quota_exceeded, _gemini_quota_exceeded_at
    import time

    # Auto-recover after 60 seconds (quota might reset)
    if _gemini_quota_exceeded and _gemini_quota_exceeded_at:
        if time.time() - _gemini_quota_exceeded_at > 60:
            _gemini_quota_exceeded = False
            print("  [Gemini quota auto-recovery — trying again]")

    if _gemini_quota_exceeded:
        return False
    if not GEMINI_API_KEY or not client:
        return False
    import socket
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=2)
        return True
    except OSError:
        return False


def mark_quota_exceeded():
    global _gemini_quota_exceeded, _gemini_quota_exceeded_at
    import time
    _gemini_quota_exceeded = True
    _gemini_quota_exceeded_at = time.time()
    print("  [Gemini quota exceeded — switching to Ollama for now. Will retry in 60s]")


def select_best_model(user_input: str, persona: str = "default") -> str:
    """
    Intelligently select the best Ollama model based on:
    1. Active persona (tutor, coder, etc.) — HIGHEST priority
    2. User input content (task type detection) — only overrides for VERY EXPLICIT requests
    3. Task complexity

    Returns: model name string
    """
    text = user_input.lower()

    # Persona-based default model selection
    persona_models = {
        "tutor": "qwen2.5:7b",       # Best for explanations & multilingual
        "coder": "qwen2.5-coder:7b",  # Best for code
        "creative": "llama3:8b",       # Good for creative tasks
        "analyst": "deepseek-r1:8b",   # Best for analysis/reasoning
    }

    preferred_model = persona_models.get(persona)

    # Detect task type from input
    best_task_type = None
    best_score = 0

    for task_type, keywords in TASK_TYPE_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text)
        if score > best_score:
            best_score = score
            best_task_type = task_type

    # CRITICAL: Persona ALWAYS takes priority unless the user makes an
    # EXPLICIT and CLEAR request that directly conflicts.
    if preferred_model and preferred_model in OLLAMA_MODELS:
        persona_task_types = {
            "tutor": ["tutoring"],
            "coder": ["code"],
            "creative": ["creative"],
            "analyst": ["reasoning"],
        }
        persona_tasks = persona_task_types.get(persona, [])

        if best_task_type in persona_tasks:
            print(f"  [Model Router: {preferred_model} — persona: {persona} (task: {best_task_type}, score: {best_score})]")
            return preferred_model

        if best_score >= 5 and best_task_type:
            task_model = TASK_MODEL_MAP.get(best_task_type, DEFAULT_OLLAMA_MODEL)
            if task_model in OLLAMA_MODELS:
                print(f"  [Model Router: {task_model} — explicit task override: {best_task_type} (score: {best_score}, persona: {persona})]")
                return task_model

        print(f"  [Model Router: {preferred_model} — persona: {persona} (task: {best_task_type}, score: {best_score})]")
        return preferred_model

    # No persona preference — use task detection
    if best_score >= 2 and best_task_type:
        task_model = TASK_MODEL_MAP.get(best_task_type, DEFAULT_OLLAMA_MODEL)
        if task_model in OLLAMA_MODELS:
            print(f"  [Model Router: {task_model} — task type: {best_task_type}]")
            return task_model

    # Final fallback
    print(f"  [Model Router: {DEFAULT_OLLAMA_MODEL} — default]")
    return DEFAULT_OLLAMA_MODEL


def chat_ollama(messages: list, model: str = None) -> str:
    """Use Ollama with smart model selection."""
    try:
        use_model = model or MODEL_OLLAMA
        clean = [{"role": m["role"], "content": m["content"]} for m in messages]
        response = ollama.chat(model=use_model, messages=clean)
        return response["message"]["content"].strip()
    except Exception as e:
        err = str(e)
        if "not found" in err.lower() or "model" in err.lower():
            print(f"  [Model {use_model} not found, falling back to {DEFAULT_OLLAMA_MODEL}]")
            try:
                clean = [{"role": m["role"], "content": m["content"]} for m in messages]
                response = ollama.chat(model=DEFAULT_OLLAMA_MODEL, messages=clean)
                return response["message"]["content"].strip()
            except Exception as e2:
                return f"Ollama error: {e2}"
        return f"Ollama error: {e}"


def chat_gemini(messages: list) -> str:
    """Use Gemini — only for final answers on complex tasks. With improved error handling."""
    global _gemini_quota_exceeded
    if not is_gemini_available():
        return chat_ollama(messages)
    try:
        system_text = ""
        history = []
        for m in messages:
            if m["role"] == "system":
                system_text = m["content"]
            elif m["role"] == "user":
                history.append(types.Content(
                    role="user",
                    parts=[types.Part(text=m["content"])]
                ))
            elif m["role"] == "assistant":
                history.append(types.Content(
                    role="model",
                    parts=[types.Part(text=m["content"])]
                ))
        if not history:
            return chat_ollama(messages)
        last_content = history[-1].parts[0].text
        prior_history = history[:-1]
        config = types.GenerateContentConfig(
            system_instruction=system_text if system_text else None,
        )
        session = client.chats.create(
            model=MODEL_GEMINI,
            history=prior_history,
            config=config,
        )
        response = session.send_message(last_content)
        return response.text.strip()
    except Exception as e:
        err = str(e)
        if "429" in err or "quota" in err.lower() or "exhausted" in err.lower() or "RESOURCE_EXHAUSTED" in err:
            mark_quota_exceeded()
            return chat_ollama(messages)
        if "503" in err or "overloaded" in err.lower():
            print("  [Gemini overloaded — falling back to Ollama]")
            return chat_ollama(messages)
        if "403" in err or "permission" in err.lower():
            print("  [Gemini API key invalid — falling back to Ollama]")
            return chat_ollama(messages)
        return f"Gemini error: {e}"


def chat(messages: list, mode: str = DEFAULT_MODE, model: str = None) -> str:
    """Route to the appropriate chat backend."""
    if mode == "ollama":
        return chat_ollama(messages, model=model)
    if mode == "gemini":
        return chat_gemini(messages)
    return chat_ollama(messages, model=model)


def should_use_gemini_for_final(user_input: str, mode: str) -> bool:
    if mode == "ollama":
        return False
    if not is_gemini_available():
        return False
    last = user_input.lower()
    if any(p in last for p in SIMPLE_PATTERNS):
        return False
    if mode == "gemini":
        return True
    return any(k in last for k in COMPLEX_KEYWORDS)


# ── Vision Model Detection & Image Analysis ──────────────────────────────────

# Known vision-capable Ollama models (ordered by preference)
_VISION_KEYWORDS = ["llava", "bakllava", "moondream", "minicpm-v", "llama3.2-vision"]


def get_available_models() -> list:
    """
    Get list of available Ollama model names.
    Handles ALL versions of the ollama Python client:
    - v0.4.x+: ListResponse object with .models attribute containing ModelDetails objects
    - v0.3.x: dict with 'models' key containing dicts with 'name' key
    - v0.1.x: dict with 'models' key containing dicts with 'name' key
    - Fallback: subprocess call to `ollama list`
    """
    models = []

    # --- Method 1: ollama Python client ---
    try:
        models_resp = ollama.list()
        print(f"  [DEBUG] ollama.list() type: {type(models_resp).__name__}")

        # New ollama Python client (0.4.x+): ListResponse object
        if hasattr(models_resp, 'models'):
            for m in models_resp.models:
                # Try every possible attribute name
                name = None
                for attr in ['model', 'name', 'id']:
                    val = getattr(m, attr, None)
                    if val and isinstance(val, str):
                        name = val
                        break
                if name:
                    models.append(name)
                else:
                    # Last resort: try dict-like access
                    try:
                        name = m.get('name', m.get('model', ''))
                        if name:
                            models.append(name)
                    except:
                        pass

        # Old ollama Python client: dict
        elif isinstance(models_resp, dict):
            for m in models_resp.get('models', []):
                if isinstance(m, dict):
                    models.append(m.get('name', m.get('model', '')))
                elif isinstance(m, str):
                    models.append(m)
                elif hasattr(m, 'model'):
                    models.append(getattr(m, 'model', ''))

        # Unknown format: try iterating
        else:
            try:
                for m in models_resp:
                    if isinstance(m, dict):
                        models.append(m.get('name', m.get('model', '')))
                    elif hasattr(m, 'model'):
                        models.append(getattr(m, 'model', ''))
                    elif hasattr(m, 'name'):
                        models.append(getattr(m, 'name', ''))
                    elif isinstance(m, str):
                        models.append(m)
            except TypeError:
                pass

        if models:
            print(f"  [DEBUG] Models from ollama.list(): {models}")
            return models

    except Exception as e:
        print(f"  [DEBUG] ollama.list() failed: {e}")

    # --- Method 2: Fallback to subprocess `ollama list` ---
    try:
        import subprocess
        result = subprocess.run(
            ['ollama', 'list'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                line = line.strip()
                if not line or line.startswith('NAME') or line.startswith('---'):
                    continue
                # Format: "model_name    id    size    modified"
                parts = line.split()
                if parts:
                    model_name = parts[0]
                    if model_name and model_name not in models:
                        models.append(model_name)
            if models:
                print(f"  [DEBUG] Models from `ollama list` CLI: {models}")
                return models
    except Exception as e:
        print(f"  [DEBUG] `ollama list` CLI failed: {e}")

    # --- Method 3: Final fallback to config ---
    print(f"  [DEBUG] Using config fallback models: {list(OLLAMA_MODELS.keys())}")
    return list(OLLAMA_MODELS.keys())


def _find_vision_model(available: list) -> str:
    """
    Find the best available vision model from the installed Ollama models.
    Uses 3-tier matching: exact → base name → keyword fuzzy.
    Returns the exact model name or None.
    """
    # Known vision model full names (most common)
    known_vision = [
        "llava:latest", "llava", "llava:7b", "llava:13b",
        "llava-llama3:latest", "llava-llama3",
        "bakllava:latest", "bakllava",
        "moondream:latest", "moondream",
        "minicpm-v:latest", "minicpm-v",
        "llama3.2-vision:latest", "llama3.2-vision",
    ]

    # Tier 1: Exact match
    for vm in known_vision:
        if vm in available:
            print(f"  [Vision] Exact match found: {vm}")
            return vm

    # Tier 2: Base name match (strip :latest/:tag)
    for vm in known_vision:
        base_vm = vm.split(':')[0]
        for av in available:
            base_av = av.split(':')[0]
            if base_vm == base_av:
                print(f"  [Vision] Base name match: {av} (pattern: {vm})")
                return av

    # Tier 3: Keyword fuzzy match
    for av in available:
        av_lower = av.lower()
        for kw in _VISION_KEYWORDS:
            if kw in av_lower:
                print(f"  [Vision] Keyword match: {av} (keyword: {kw})")
                return av

    print(f"  [Vision] No vision model found in: {available}")
    return None


def _try_ollama_vision(text: str, images: list) -> str:
    """
    Try Ollama vision models (llava, etc.) for image analysis.
    Returns result string or None if failed.
    """
    try:
        available = get_available_models()
        if not available:
            print("  [Vision ERROR] No Ollama models found at all!")
            return None

        exact_model = _find_vision_model(available)
        if not exact_model:
            return None

        # Prepare image data
        ollama_images = []
        for img in images:
            img_data = img.get('base64', '')
            if img_data:
                ollama_images.append(img_data)

        if not ollama_images:
            print("  [Vision ERROR] No valid image base64 data found")
            return None

        print(f"  [Vision] Calling ollama.chat with model={exact_model}, {len(ollama_images)} image(s)")

        # Try ollama.chat() with images
        try:
            response = ollama.chat(
                model=exact_model,
                messages=[{
                    "role": "user",
                    "content": text,
                    "images": ollama_images
                }]
            )
            result = response["message"]["content"].strip()
            if result:
                print(f"  [Vision SUCCESS] Response length: {len(result)} chars")
                return result
            else:
                print("  [Vision ERROR] ollama.chat returned empty response")
        except Exception as e:
            print(f"  [Vision ERROR] ollama.chat() failed: {e}")

            # Fallback: try ollama.generate() instead
            print(f"  [Vision] Trying ollama.generate() as fallback...")
            try:
                response = ollama.generate(
                    model=exact_model,
                    prompt=text,
                    images=ollama_images
                )
                result = response.get("response", "").strip()
                if result:
                    print(f"  [Vision SUCCESS via generate()] Response length: {len(result)} chars")
                    return result
                else:
                    print("  [Vision ERROR] ollama.generate() returned empty response")
            except Exception as e2:
                print(f"  [Vision ERROR] ollama.generate() also failed: {e2}")

        return None

    except Exception as e:
        print(f"  [Vision ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return None


def chat_with_images(text: str, images: list) -> str:
    """
    Send text + images for vision analysis.
    Tries: 1) Gemini Vision → 2) Ollama vision models (llava) → 3) Helpful fallback
    images: list of {base64: str, mime: str}
    """
    print(f"  [Vision] chat_with_images called with {len(images)} image(s)")

    # Step 1: Try Gemini Vision (best quality)
    if is_gemini_available():
        try:
            import base64
            parts = []
            for img in images:
                parts.append(types.Part(
                    inline_data=types.Blob(
                        mime_type=img.get('mime', 'image/jpeg'),
                        data=base64.b64decode(img['base64'])
                    )
                ))
            parts.append(types.Part(text=text))
            response = client.models.generate_content(
                model=MODEL_GEMINI,
                contents=[types.Content(role="user", parts=parts)]
            )
            print(f"  [Vision SUCCESS] Gemini Vision responded")
            return response.text.strip()
        except Exception as e:
            err = str(e)
            if "429" in err or "quota" in err.lower():
                mark_quota_exceeded()
                print("  [Vision] Gemini quota exceeded — falling back to Ollama vision")
            elif "503" in err or "overloaded" in err.lower():
                print("  [Vision] Gemini overloaded — falling back to Ollama vision")
            else:
                print(f"  [Vision] Gemini error: {e} — falling back to Ollama vision")

    # Step 2: Try Ollama vision models (llava, moondream, etc.)
    vision_result = _try_ollama_vision(text, images)
    if vision_result:
        return vision_result

    # Step 3: Helpful fallback message with diagnostics
    try:
        available = get_available_models()
        vision_model = _find_vision_model(available)
        diag_info = f"Models detected: {available}\nVision model found: {vision_model}"
    except:
        diag_info = "Could not query Ollama models"

    print(f"  [Vision FAILED] All vision methods failed. {diag_info}")

    return (
        "I can see you've shared an image! Unfortunately, I'm currently unable to analyze it directly because:\n\n"
        "- **Gemini Vision** is temporarily unavailable (quota exceeded or not configured)\n"
        "- **Ollama vision model** (like `llava`) could not process the image\n\n"
        "**How to fix this:**\n"
        "1. Run `ollama pull llava` in your terminal to install a local vision model\n"
        "2. **Restart the Aria server** after installing (this is important!)\n"
        "3. Check the server console for any error messages about vision\n"
        "4. Visit http://localhost:5000/vision-test to diagnose vision model detection\n\n"
        "**In the meantime:** If you can describe what's in the image, I can help you with detailed text-based analysis, explanations, and questions about it!"
    )


def check_ollama_health() -> dict:
    """Check which Ollama models are actually running/available."""
    result = {}
    try:
        available = get_available_models()
        for model_name in OLLAMA_MODELS:
            is_available = any(model_name in av for av in available)
            result[model_name] = {
                "available": is_available,
                "info": OLLAMA_MODELS[model_name],
            }
        # Also check for vision models not in OLLAMA_MODELS
        vision_model = _find_vision_model(available)
        if vision_model and vision_model not in result:
            result[vision_model] = {
                "available": True,
                "info": {"strengths": ["vision", "image_analysis"], "category": "vision"},
            }
    except Exception as e:
        result["error"] = str(e)
    return result


def has_vision_model() -> bool:
    """Quick check if any Ollama vision model is available."""
    try:
        available = get_available_models()
        return _find_vision_model(available) is not None
    except:
        return False


def vision_diagnostic() -> dict:
    """
    Full diagnostic of vision model detection.
    Returns detailed info for debugging.
    """
    diag = {
        "step1_ollama_list": {},
        "step2_model_parsing": {},
        "step3_vision_detection": {},
        "step4_direct_test": {},
    }

    # Step 1: Raw ollama.list() response
    try:
        resp = ollama.list()
        diag["step1_ollama_list"]["type"] = type(resp).__name__
        diag["step1_ollama_list"]["has_models_attr"] = hasattr(resp, 'models')
        diag["step1_ollama_list"]["is_dict"] = isinstance(resp, dict)

        if hasattr(resp, 'models'):
            raw_models = []
            for m in resp.models:
                info = {"type": type(m).__name__}
                for attr in ['model', 'name', 'id', 'size', 'digest', 'modified_at']:
                    val = getattr(m, attr, "NOT_FOUND")
                    info[attr] = str(val) if val != "NOT_FOUND" else "NOT_FOUND"
                raw_models.append(info)
            diag["step1_ollama_list"]["models_detail"] = raw_models
        elif isinstance(resp, dict):
            diag["step1_ollama_list"]["raw"] = str(resp)[:2000]
    except Exception as e:
        diag["step1_ollama_list"]["error"] = str(e)

    # Step 2: Parsed model names
    try:
        models = get_available_models()
        diag["step2_model_parsing"]["models"] = models
        diag["step2_model_parsing"]["count"] = len(models)
    except Exception as e:
        diag["step2_model_parsing"]["error"] = str(e)

    # Step 3: Vision model detection
    try:
        models = get_available_models()
        vision = _find_vision_model(models)
        diag["step3_vision_detection"]["available_models"] = models
        diag["step3_vision_detection"]["vision_model_found"] = vision
        diag["step3_vision_detection"]["has_vision"] = vision is not None
    except Exception as e:
        diag["step3_vision_detection"]["error"] = str(e)

    # Step 4: Direct ollama.chat test with llava (no images, just connectivity)
    try:
        models = get_available_models()
        vision = _find_vision_model(models)
        if vision:
            # Simple text-only test to verify the model responds
            try:
                resp = ollama.chat(
                    model=vision,
                    messages=[{"role": "user", "content": "Say 'vision model working' in 3 words."}]
                )
                diag["step4_direct_test"]["model"] = vision
                diag["step4_direct_test"]["text_test"] = "SUCCESS"
                diag["step4_direct_test"]["response_preview"] = resp["message"]["content"][:200]
            except Exception as e:
                diag["step4_direct_test"]["model"] = vision
                diag["step4_direct_test"]["text_test"] = f"FAILED: {e}"
        else:
            diag["step4_direct_test"]["skipped"] = "No vision model found to test"
    except Exception as e:
        diag["step4_direct_test"]["error"] = str(e)

    return diag
