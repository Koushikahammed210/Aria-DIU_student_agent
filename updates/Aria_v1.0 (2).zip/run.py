# run.py

import sys
import os
from agent import Agent, PlannerAgent, _CoverPageSession
from config import AGENT_NAME


def run_cli():
    print("=" * 52)
    print(f"   {AGENT_NAME} — Local AI Agent  [CLI]")
    print("=" * 52)
    agent = Agent()
    planner = PlannerAgent()
    cover = _CoverPageSession()

    while True:
        try:
            user_input = input("\nYou: ").strip()
        except KeyboardInterrupt:
            print("\nGoodbye!"); break
        if not user_input: continue
        if user_input.lower() in ("quit","exit","bye"): print("Goodbye!"); break
        if user_input.lower() == "clear": agent.memory.clear(); continue
        if user_input.lower().startswith("planner "):
            print(f"\n{AGENT_NAME}:", planner.run(user_input[8:].strip())); continue
        if user_input.lower() in ("cover","cover page"):
            print(f"\n{AGENT_NAME}:", cover.start()); continue
        if cover.active:
            r = cover.handle(user_input)
            print(f"\n{AGENT_NAME}:", r['reply']); continue
        print(f"\n{AGENT_NAME}:", agent.chat(user_input))


def run_web():
    from flask import Flask, request, jsonify, send_from_directory, send_file
    import llm

    app = Flask(__name__, static_folder="static")
    agent  = Agent()
    planner = PlannerAgent()
    cover  = _CoverPageSession()

    # ── Startup diagnostics ──────────────────────────────────────────────────
    print(f"\n{'='*50}")
    print(f"  {AGENT_NAME} — Startup Diagnostics")
    print(f"{'='*50}")
    try:
        models = llm.get_available_models()
        print(f"  Ollama models ({len(models)}): {', '.join(models) if models else 'none detected'}")
    except Exception as e:
        models = []
        print(f"  Ollama models: error listing — {e}")
    vision_model = llm._find_vision_model()
    print(f"  Vision model:  {vision_model or 'NOT FOUND'}")
    gemini_ok = llm.is_gemini_available()
    print(f"  Gemini API:    {'available' if gemini_ok else 'unavailable'}")
    print(f"  Image analysis: {'Gemini + Ollama Vision' if vision_model and gemini_ok else 'Ollama Vision only' if vision_model else 'Gemini only' if gemini_ok else 'NOT AVAILABLE'}")
    if not vision_model and not gemini_ok:
        print(f"\n  ⚠ WARNING: No vision model available! Install llava:")
        print(f"    ollama pull llava")
    print(f"{'='*50}\n")

    @app.route("/")
    def index():
        return send_from_directory("static", "index.html")

    @app.route("/chat", methods=["POST"])
    def chat():
        import llm as llm_mod
        data        = request.json
        user_input  = data.get("message", "").strip()
        use_planner = data.get("planner", False)
        images      = data.get("images", [])   # [{base64, mime}]

        if not user_input and not images:
            return jsonify({"reply": "Please enter a message."})

        # If images are attached, send to vision models
        if images:
            reply = llm_mod.chat_with_images(user_input or "Describe this image.", images)
            return jsonify({"reply": reply})

        if use_planner:
            reply = planner.run(user_input)
        else:
            reply = agent.chat(user_input)
        return jsonify({"reply": reply})

    @app.route("/cover-chat", methods=["POST"])
    def cover_chat():
        data   = request.json
        action = data.get("action", "message")
        if action == "start":
            cover.reset()
            return jsonify({"reply": cover.start(), "active": cover.active})
        if action == "cancel":
            cover.reset()
            return jsonify({"reply": "Cover page creation cancelled.", "active": False})
        msg = data.get("message", "").strip()
        if not msg:
            return jsonify({"reply": "Please enter a response.", "active": cover.active})
        result = cover.handle(msg)
        return jsonify(result)

    @app.route("/cover", methods=["POST"])
    def cover_direct():
        from tools import generate_covers
        import json
        data = request.json
        if not data:
            return jsonify({"reply": "No data received."})
        try:
            result = generate_covers(json.dumps(data))
            return jsonify({"reply": result})
        except Exception as e:
            return jsonify({"reply": f"Error: {e}"})

    @app.route("/clear", methods=["POST"])
    def clear():
        agent.memory.clear()
        return jsonify({"status": "Memory cleared."})

    @app.route("/status", methods=["GET"])
    def status():
        import llm as llm_mod
        vision_model = llm_mod._find_vision_model()
        return jsonify({
            "mode": agent.mode,
            "messages": len(agent.memory.messages),
            "ollama_model": llm_mod.MODEL_OLLAMA,
            "gemini_model": llm_mod.MODEL_GEMINI,
            "gemini_available": llm_mod.is_gemini_available(),
            "vision_model": vision_model,
            "vision_available": vision_model is not None,
        })

    @app.route("/models", methods=["GET"])
    def list_models():
        import llm as llm_mod
        try:
            models = llm_mod.get_available_models()
            vision_model = llm_mod._find_vision_model()
            return jsonify({
                "ollama_models": models,
                "vision_model": vision_model,
                "vision_available": vision_model is not None,
                "gemini_available": llm_mod.is_gemini_available(),
            })
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/mode", methods=["POST"])
    def set_mode():
        mode = request.json.get("mode", "auto")
        if mode in ("ollama", "gemini", "auto"):
            agent.mode = mode
            planner.mode = mode
            return jsonify({"status": f"Switched to {mode} mode."})
        return jsonify({"status": "Unknown mode."}), 400

    @app.route("/download/<filename>")
    def download(filename):
        safe = os.path.basename(filename)
        fp   = os.path.join(os.getcwd(), safe)
        if not os.path.exists(fp):
            return jsonify({"error": f"File not found: {safe}"}), 404
        try:
            return send_file(fp, as_attachment=True, download_name=safe)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    print(f"{AGENT_NAME} → http://localhost:5000\n")
    app.run(debug=False, port=5000)


if __name__ == "__main__":
    if "--web" in sys.argv:
        run_web()
    else:
        run_cli()
